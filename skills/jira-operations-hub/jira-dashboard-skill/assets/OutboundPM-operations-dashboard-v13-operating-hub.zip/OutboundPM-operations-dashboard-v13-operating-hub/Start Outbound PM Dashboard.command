#!/bin/zsh
set -e

cd "$(dirname "$0")"

echo "Starting Outbound PM Operations Dashboard..."
echo "Open this address in your browser:"
echo "http://127.0.0.1:8901/"
echo

./run_dashboard.sh 8901
