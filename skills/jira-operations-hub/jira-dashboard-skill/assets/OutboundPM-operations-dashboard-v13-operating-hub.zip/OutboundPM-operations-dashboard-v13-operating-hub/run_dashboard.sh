#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

PORT="${1:-8765}"
HOST="${HOST:-127.0.0.1}"
if [[ $# -gt 0 ]]; then
  shift
fi

echo "Starting Outbound PM Operations Dashboard on http://${HOST}:${PORT}"
python3 server.py --host "$HOST" --port "$PORT" "$@"
