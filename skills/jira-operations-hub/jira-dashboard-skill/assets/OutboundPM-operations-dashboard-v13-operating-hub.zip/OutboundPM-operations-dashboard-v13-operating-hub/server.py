#!/usr/bin/env python3
"""
Outbound PM Operations Dashboard server

Serves a modern single-page dashboard (index.html) and bridges browser calls
to the local Jira MCP server (mcp-atlassian) over stdio.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import json
import os
import queue
import re
import subprocess
import sys
import threading
import time as monotonic_time
import webbrowser
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from functools import lru_cache
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from socketserver import TCPServer
from typing import Any
from urllib.parse import parse_qs, quote, unquote, urlparse
from urllib.request import Request, urlopen

import tomllib


PROTOCOL_VERSIONS = ["2025-03-26", "2024-11-05", "2024-10-07"]
MAX_PAGES = 25
PAGE_SIZE = 50
MAX_HISTORY_ISSUES = 80
MAX_BURNDOWN_DAYS = 90

DONE_STATUS_NAMES = {"done", "closed", "resolved", "complete", "completed"}
BLOCKED_STATUS_MARKERS = ("blocked", "hold")


def env_float(name: str, default: float) -> float:
    raw = os.environ.get(name)
    if raw is None:
        return default
    text = str(raw).strip()
    if not text:
        return default
    try:
        value = float(text)
    except ValueError:
        return default
    if value < 0:
        return 0.0
    return value


SEARCH_CACHE_TTL_SECONDS = env_float("JIRAPAT_SEARCH_CACHE_TTL_SECONDS", 20.0)
REPORTS_CACHE_TTL_SECONDS = env_float("JIRAPAT_REPORTS_CACHE_TTL_SECONDS", 20.0)
HISTORY_CACHE_TTL_SECONDS = env_float("JIRAPAT_HISTORY_CACHE_TTL_SECONDS", 180.0)
CREATE_META_CACHE_TTL_SECONDS = env_float("JIRAPAT_CREATE_META_CACHE_TTL_SECONDS", 180.0)

SEARCH_CACHE_MAX_ENTRIES = 24
REPORTS_CACHE_MAX_ENTRIES = 16
HISTORY_CACHE_MAX_ENTRIES = 400
CREATE_META_CACHE_MAX_ENTRIES = 16

APP_VERSION = os.environ.get("JIRAPAT_VERSION", "v13-operating-hub")
DEFAULT_UPDATE_SOURCE_URL = os.environ.get(
    "JIRAPAT_UPDATE_SOURCE_URL",
    "https://oracle-my.sharepoint.com/:f:/p/kay_malcolm/IgAAD-j8HQ45TrN6ftHIlbGmAepcNGqno8P6Z3yEUikwKRs?e=AvELJl",
)
DIST_VERSION_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(
        r"JiraPat[-_ ]dashboard[-_ ]distribution[-_ ]v(\d+)(?:\.zip)?\b",
        flags=re.IGNORECASE,
    ),
    re.compile(
        r"JiraPat%2Ddashboard%2Ddistribution%2Dv(\d+)(?:%2Ezip)?\b",
        flags=re.IGNORECASE,
    ),
)
VERSION_CHECK_EXECUTOR = concurrent.futures.ThreadPoolExecutor(
    max_workers=2,
    thread_name_prefix="jpat-version-check",
)


@dataclass
class MCPServerConfig:
    command: str
    args: list[str]
    env: dict[str, str]


def try_parse_json(text: str) -> Any | None:
    if not isinstance(text, str):
        return None
    candidate = text.strip()
    if not candidate:
        return None

    if candidate.startswith("```"):
        lines = candidate.splitlines()
        if len(lines) >= 3:
            candidate = "\n".join(lines[1:-1]).strip()

    try:
        return json.loads(candidate)
    except json.JSONDecodeError:
        return None


def split_csv(value: str) -> list[str]:
    if not value:
        return []
    return [part.strip() for part in value.split(",") if part.strip()]


def parse_version_number(version_text: str) -> int | None:
    match = re.search(r"v(\d+)", version_text or "", flags=re.IGNORECASE)
    if not match:
        return None
    try:
        return int(match.group(1))
    except ValueError:
        return None


def extract_distribution_versions(text: str) -> list[int]:
    corpus = [text or ""]
    try:
        decoded = unquote(text or "")
        if decoded and decoded != (text or ""):
            corpus.append(decoded)
    except Exception:
        pass

    versions: set[int] = set()
    for candidate in corpus:
        for pattern in DIST_VERSION_PATTERNS:
            for match in pattern.finditer(candidate):
                try:
                    versions.add(int(match.group(1)))
                except ValueError:
                    continue

    return sorted(versions)


def fetch_update_source_snapshot(source_url: str) -> tuple[str, str]:
    request = Request(
        source_url,
        headers={
            "User-Agent": "OutboundPMOperationsDashboard/1.0",
            "Accept": "text/html,application/json;q=0.9,*/*;q=0.8",
        },
    )
    with urlopen(request, timeout=15) as response:
        body = response.read(512_000).decode("utf-8", errors="ignore")
        content_type = response.headers.get("Content-Type", "")
    return body, content_type


def jql_quote(value: str) -> str:
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def format_jira_datetime_for_jql(value: str) -> str | None:
    parsed = parse_datetime_safe(value)
    if parsed is None:
        return None
    if parsed.tzinfo is not None:
        parsed = parsed.astimezone(timezone.utc).replace(tzinfo=None)
    return parsed.strftime("%Y/%m/%d %H:%M")


def append_jql_clause(jql: str, clause: str) -> str:
    base = (jql or "").strip()
    if not base or not clause:
        return base

    order_match = re.search(r"\border\s+by\b", base, flags=re.IGNORECASE)
    if order_match:
        body = base[: order_match.start()].strip()
        order_by = base[order_match.start() :].strip()
    else:
        body = base
        order_by = ""

    combined = f"({body}) AND {clause}" if body else clause
    return f"{combined} {order_by}".strip()


def pick_display_name(user: Any) -> str:
    if not isinstance(user, dict):
        return ""
    return (
        user.get("display_name")
        or user.get("displayName")
        or user.get("name")
        or user.get("email")
        or ""
    )


def extract_status_category(status_obj: Any) -> str:
    if not isinstance(status_obj, dict):
        return ""
    category = status_obj.get("category")
    if isinstance(category, dict):
        return category.get("name") or ""
    if isinstance(category, str):
        return category
    return ""


def extract_sprint_name(sprint: Any) -> str:
    if isinstance(sprint, str):
        return sprint
    if isinstance(sprint, dict):
        return sprint.get("name") or ""
    if isinstance(sprint, list):
        names: list[str] = []
        for item in sprint:
            if isinstance(item, dict) and item.get("name"):
                names.append(str(item["name"]))
            elif isinstance(item, str):
                names.append(item)
        return ", ".join(names)
    return ""


def build_jira_url(base_url: str, issue_key: str) -> str:
    if not issue_key:
        return ""
    base = base_url.rstrip("/")
    return f"{base}/browse/{quote(issue_key)}"


def int_or_none(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def parse_estimate_text_to_seconds(value: Any) -> int | None:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return int(value)
    if not isinstance(value, str):
        return None

    text = value.strip().lower()
    if not text:
        return None

    # If it's raw numeric text, treat as seconds.
    if re.fullmatch(r"[+-]?\d+(?:\.\d+)?", text):
        try:
            return int(float(text))
        except ValueError:
            return None

    unit_seconds = {
        "w": 5 * 8 * 3600,  # Jira default: 5d/week, 8h/day
        "d": 8 * 3600,
        "h": 3600,
        "m": 60,
        "s": 1,
    }

    total = 0.0
    matched = False
    for number, unit in re.findall(r"([+-]?\d+(?:\.\d+)?)\s*([wdhms])", text):
        matched = True
        try:
            total += float(number) * unit_seconds[unit]
        except ValueError:
            continue

    if matched:
        return int(total)

    return None


@lru_cache(maxsize=4096)
def _parse_datetime_raw(raw: str) -> datetime | None:
    candidates = [
        raw,
        raw.replace("Z", "+00:00"),
    ]

    if len(raw) >= 5 and raw[-5] in ("+", "-") and raw[-3] != ":":
        # Convert -0700 -> -07:00 for fromisoformat.
        candidates.append(raw[:-2] + ":" + raw[-2:])

    for candidate in candidates:
        try:
            dt = datetime.fromisoformat(candidate)
            if dt.tzinfo is None:
                return dt.replace(tzinfo=timezone.utc)
            return dt
        except ValueError:
            continue

    for fmt in (
        "%Y-%m-%dT%H:%M:%S.%f%z",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%d",
    ):
        try:
            dt = datetime.strptime(raw, fmt)
            if dt.tzinfo is None:
                return dt.replace(tzinfo=timezone.utc)
            return dt
        except ValueError:
            continue

    return None


def parse_datetime_safe(value: Any) -> datetime | None:
    if not isinstance(value, str):
        return None
    raw = value.strip()
    if not raw:
        return None
    return _parse_datetime_raw(raw)


def status_bucket(status: str) -> str:
    text = (status or "").strip().lower()
    if any(marker in text for marker in BLOCKED_STATUS_MARKERS):
        return "Blocked / On Hold"
    if "progress" in text:
        return "In Progress"
    if text in DONE_STATUS_NAMES:
        return "Done"
    if text in ("to do", "todo", "open", "reopened", "backlog"):
        return "To Do"
    if any(done_marker in text for done_marker in DONE_STATUS_NAMES):
        return "Done"
    return "To Do"


def load_mcp_server_config(server_name: str = "mcp-atlassian") -> MCPServerConfig:
    config_path = Path.home() / ".codex" / "config.toml"
    if not config_path.exists():
        raise FileNotFoundError(f"Codex config not found: {config_path}")

    data = tomllib.loads(config_path.read_text(encoding="utf-8"))
    mcp_servers = data.get("mcp_servers") or {}
    entry = mcp_servers.get(server_name)
    if not isinstance(entry, dict):
        raise RuntimeError(f"MCP server '{server_name}' not found in {config_path}")

    command = entry.get("command")
    if not command:
        raise RuntimeError(f"MCP server '{server_name}' has no command in {config_path}")

    args = [str(arg) for arg in entry.get("args") or []]
    env = {k: str(v) for k, v in (entry.get("env") or {}).items()}
    return MCPServerConfig(command=str(command), args=args, env=env)


class MCPStdioClient:
    def __init__(self, config: MCPServerConfig, suppress_insecure_warning: bool = True) -> None:
        self._config = config
        self._suppress_insecure_warning = bool(suppress_insecure_warning)
        self._process: subprocess.Popen[bytes] | None = None
        self._writer_lock = threading.Lock()
        self._state_lock = threading.Lock()
        self._startup_lock = threading.Lock()
        self._pending: dict[int, queue.Queue[dict[str, Any]]] = {}
        self._next_id = 1
        self._tool_names: set[str] = set()
        self._ready = False

    @property
    def started(self) -> bool:
        return self._ready and self._process is not None and self._process.poll() is None

    @property
    def tool_names(self) -> list[str]:
        return sorted(self._tool_names)

    def _start_process(self) -> None:
        env = os.environ.copy()
        env.update(self._config.env)

        cmd = [self._config.command, *self._config.args]
        process = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            bufsize=0,
        )
        self._process = process

        assert process.stdout is not None
        assert process.stderr is not None

        threading.Thread(target=self._stdout_reader_loop, args=(process,), daemon=True).start()
        threading.Thread(target=self._stderr_reader_loop, args=(process,), daemon=True).start()

    def _stderr_reader_loop(self, process: subprocess.Popen[bytes]) -> None:
        if not process.stderr:
            return
        suppress_next_source_line = False
        while True:
            line = process.stderr.readline()
            if not line:
                return
            try:
                text = line.decode("utf-8", "replace").rstrip()
            except Exception:
                text = repr(line)
            if self._suppress_insecure_warning:
                if "InsecureRequestWarning" in text:
                    suppress_next_source_line = True
                    continue
                if "Jira SSL verification disabled" in text:
                    continue
                if suppress_next_source_line:
                    suppress_next_source_line = False
                    if text.strip().startswith("warnings.warn"):
                        continue
            if text:
                print(f"[mcp-atlassian] {text}", file=sys.stderr)

    def _read_message(self, process: subprocess.Popen[bytes]) -> dict[str, Any] | None:
        if not process.stdout:
            return None

        while True:
            line = process.stdout.readline()
            if not line:
                return None

            decoded = line.decode("utf-8", "replace").strip()
            if not decoded:
                continue

            try:
                return json.loads(decoded)
            except json.JSONDecodeError:
                # Ignore non-JSON lines, keep reading.
                continue

    def _stdout_reader_loop(self, process: subprocess.Popen[bytes]) -> None:
        while True:
            message = self._read_message(process)
            if message is None:
                if self._process is process:
                    self._fail_all_pending("MCP server connection closed")
                return

            message_id = message.get("id")
            if message_id is None:
                continue

            with self._state_lock:
                pending = self._pending.pop(message_id, None)

            if pending is not None:
                pending.put(message)

    def _fail_all_pending(self, reason: str) -> None:
        with self._state_lock:
            pending_items = list(self._pending.items())
            self._pending.clear()
            self._ready = False

        for req_id, resp_queue in pending_items:
            resp_queue.put(
                {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "error": {"code": -32000, "message": reason},
                }
            )

    def _send(self, message: dict[str, Any]) -> None:
        if not self._process or not self._process.stdin:
            raise RuntimeError("MCP process not started")

        wire = (json.dumps(message, separators=(",", ":")) + "\n").encode("utf-8")

        with self._writer_lock:
            self._process.stdin.write(wire)
            self._process.stdin.flush()

    def request(
        self,
        method: str,
        params: dict[str, Any] | None = None,
        timeout: int = 90,
        ensure_session: bool = True,
    ) -> dict[str, Any]:
        if ensure_session:
            self.ensure_started()

        with self._state_lock:
            request_id = self._next_id
            self._next_id += 1
            response_queue: queue.Queue[dict[str, Any]] = queue.Queue(maxsize=1)
            self._pending[request_id] = response_queue

        self._send(
            {
                "jsonrpc": "2.0",
                "id": request_id,
                "method": method,
                "params": params or {},
            }
        )

        try:
            response = response_queue.get(timeout=timeout)
        except queue.Empty as exc:
            with self._state_lock:
                self._pending.pop(request_id, None)
            raise TimeoutError(f"Timed out waiting for MCP response to {method}") from exc

        if "error" in response:
            error = response["error"]
            raise RuntimeError(f"MCP error for {method}: {error}")

        result = response.get("result")
        if isinstance(result, dict):
            return result

        return {"value": result}

    def notify(self, method: str, params: dict[str, Any] | None = None) -> None:
        self.ensure_started()
        self._send({"jsonrpc": "2.0", "method": method, "params": params or {}})

    def ensure_started(self) -> None:
        if self.started:
            return

        with self._startup_lock:
            if self.started:
                return
            with self._state_lock:
                self._ready = False
            self._start_process()

            try:
                self._initialize()
                self._discover_tools()
                with self._state_lock:
                    self._ready = True
            except Exception:
                self.close()
                raise

    def _initialize(self) -> None:
        errors: list[str] = []

        for version in PROTOCOL_VERSIONS:
            try:
                self.request(
                    "initialize",
                    {
                        "protocolVersion": version,
                        "capabilities": {},
                        "clientInfo": {
                            "name": "OutboundPMOperationsDashboard",
                            "version": "1.0.0",
                        },
                    },
                    timeout=120,
                    ensure_session=False,
                )

                self._send(
                    {
                        "jsonrpc": "2.0",
                        "method": "notifications/initialized",
                        "params": {},
                    }
                )
                return
            except Exception as exc:
                errors.append(f"{version}: {exc}")

        raise RuntimeError("Failed to initialize MCP session. " + " | ".join(errors))

    def _discover_tools(self) -> None:
        result = self.request("tools/list", {}, timeout=120, ensure_session=False)
        tools = result.get("tools")
        if isinstance(tools, list):
            names = set()
            for tool in tools:
                if isinstance(tool, dict) and tool.get("name"):
                    names.add(str(tool["name"]))
            self._tool_names = names

    def _resolve_tool_name(self, requested: str) -> str:
        if not self._tool_names:
            return requested

        if requested in self._tool_names:
            return requested

        candidates = [
            f"mcp__mcp_atlassian__{requested}",
            f"mcp-atlassian.{requested}",
        ]
        for candidate in candidates:
            if candidate in self._tool_names:
                return candidate

        for name in self._tool_names:
            if name.endswith(requested):
                return name

        raise RuntimeError(
            f"Tool '{requested}' not found. Available tools include: "
            + ", ".join(sorted(self._tool_names)[:25])
        )

    def call_tool(self, name: str, arguments: dict[str, Any], timeout: int = 120) -> Any:
        resolved_name = self._resolve_tool_name(name)
        result = self.request(
            "tools/call",
            {
                "name": resolved_name,
                "arguments": arguments,
            },
            timeout=timeout,
        )

        if result.get("isError"):
            raise RuntimeError(f"Tool call error ({resolved_name}): {result}")

        return self._extract_tool_payload(result)

    def _extract_tool_payload(self, result: dict[str, Any]) -> Any:
        if "structuredContent" in result:
            return result["structuredContent"]

        content = result.get("content")
        if not isinstance(content, list):
            return result

        text_chunks: list[str] = []
        for item in content:
            if not isinstance(item, dict):
                continue
            if item.get("type") == "text" and isinstance(item.get("text"), str):
                text_chunks.append(item["text"])
            elif "json" in item:
                return item["json"]

        if not text_chunks:
            return result

        merged = "\n".join(text_chunks).strip()
        parsed = try_parse_json(merged)

        if isinstance(parsed, dict) and "result" in parsed:
            inner = parsed.get("result")
            if isinstance(inner, str):
                inner_parsed = try_parse_json(inner)
                return inner_parsed if inner_parsed is not None else inner
            return inner

        return parsed if parsed is not None else merged

    def close(self) -> None:
        process = self._process
        self._process = None
        self._ready = False
        self._tool_names = set()

        if process is None:
            return

        try:
            process.terminate()
            process.wait(timeout=3)
        except Exception:
            try:
                process.kill()
            except Exception:
                pass


class JiraDashboardBridge:
    def __init__(self, mcp_config: MCPServerConfig, suppress_insecure_warning: bool = True) -> None:
        self.client = MCPStdioClient(
            mcp_config,
            suppress_insecure_warning=suppress_insecure_warning,
        )
        self.jira_base_url = mcp_config.env.get("JIRA_URL", "https://jira.oraclecorp.com/jira").rstrip("/")
        self.jira_username = mcp_config.env.get("JIRA_USERNAME", "")
        self._cache_lock = threading.Lock()
        self._search_cache: dict[str, tuple[float, dict[str, Any]]] = {}
        self._reports_cache: dict[str, tuple[float, dict[str, Any]]] = {}
        self._history_cache: dict[str, tuple[float, dict[str, Any]]] = {}
        self._create_meta_cache: dict[str, tuple[float, dict[str, Any]]] = {}

    def ensure_ready(self) -> None:
        self.client.ensure_started()

    def close(self) -> None:
        self.client.close()

    def _cache_get(self, store: dict[str, tuple[float, Any]], key: str) -> Any | None:
        now = monotonic_time.monotonic()
        with self._cache_lock:
            entry = store.get(key)
            if entry is None:
                return None
            expires_at, value = entry
            if expires_at <= now:
                store.pop(key, None)
                return None
        return value

    def _cache_set(
        self,
        store: dict[str, tuple[float, Any]],
        key: str,
        value: Any,
        *,
        ttl_seconds: float,
        max_entries: int,
    ) -> None:
        if ttl_seconds <= 0:
            return
        now = monotonic_time.monotonic()
        expires_at = now + ttl_seconds
        with self._cache_lock:
            store[key] = (expires_at, value)

            expired_keys = [entry_key for entry_key, (entry_expiry, _) in store.items() if entry_expiry <= now]
            for entry_key in expired_keys:
                store.pop(entry_key, None)

            if len(store) > max_entries:
                overflow = len(store) - max_entries
                for entry_key, _ in sorted(store.items(), key=lambda item: item[1][0])[:overflow]:
                    store.pop(entry_key, None)

    def _invalidate_query_caches(self) -> None:
        with self._cache_lock:
            self._search_cache.clear()
            self._reports_cache.clear()
            self._create_meta_cache.clear()

    def _search_cache_key(self, jql: str, fields: list[str]) -> str:
        normalized_fields = [str(field).strip() for field in fields if str(field).strip()]
        payload = {"jql": (jql or "").strip(), "fields": normalized_fields}
        return json.dumps(payload, separators=(",", ":"), sort_keys=True)

    def _projects_cache_key(self, projects: list[str]) -> str:
        normalized = sorted({str(project).strip().upper() for project in projects if str(project).strip()})
        return ",".join(normalized)

    def search_issues(self, jql: str, fields: list[str]) -> dict[str, Any]:
        started = monotonic_time.monotonic()
        cache_key = self._search_cache_key(jql, fields)
        cached = self._cache_get(self._search_cache, cache_key)
        if isinstance(cached, dict):
            result = dict(cached)
            result["diagnostics"] = {
                **dict(cached.get("diagnostics") or {}),
                "cache_hit": True,
                "duration_ms": round((monotonic_time.monotonic() - started) * 1000),
                "cache_ttl_seconds": SEARCH_CACHE_TTL_SECONDS,
            }
            return result

        all_issues: list[dict[str, Any]] = []
        total: int | None = None
        start_at = 0

        for _ in range(MAX_PAGES):
            payload = self.client.call_tool(
                "jira_search",
                {
                    "jql": jql,
                    "fields": ",".join(fields),
                    "limit": PAGE_SIZE,
                    "start_at": start_at,
                },
                timeout=180,
            )

            page = self._normalize_search_payload(payload)
            page_issues = page.get("issues") if isinstance(page, dict) else None
            if not isinstance(page_issues, list):
                page_issues = []

            all_issues.extend(page_issues)

            if total is None:
                raw_total = page.get("total") if isinstance(page, dict) else None
                try:
                    total = int(raw_total) if raw_total is not None else None
                except (TypeError, ValueError):
                    total = None

            if not page_issues:
                break

            start_at += len(page_issues)
            if total is not None and start_at >= total:
                break

        normalized = [self._normalize_issue(issue) for issue in all_issues]

        result = {
            "jql": jql,
            "total": len(normalized),
            "issues": normalized,
            "fetched_at": datetime.now(timezone.utc).isoformat(),
            "diagnostics": {
                "cache_hit": False,
                "duration_ms": round((monotonic_time.monotonic() - started) * 1000),
                "page_size": PAGE_SIZE,
                "max_pages": MAX_PAGES,
                "cache_ttl_seconds": SEARCH_CACHE_TTL_SECONDS,
            },
        }
        self._cache_set(
            self._search_cache,
            cache_key,
            result,
            ttl_seconds=SEARCH_CACHE_TTL_SECONDS,
            max_entries=SEARCH_CACHE_MAX_ENTRIES,
        )
        return result

    def build_reports(self, jql: str, fields: list[str]) -> dict[str, Any]:
        started = monotonic_time.monotonic()
        cache_key = self._search_cache_key(jql, fields)
        cached = self._cache_get(self._reports_cache, cache_key)
        if isinstance(cached, dict):
            result = dict(cached)
            result["diagnostics"] = {
                **dict(cached.get("diagnostics") or {}),
                "cache_hit": True,
                "duration_ms": round((monotonic_time.monotonic() - started) * 1000),
                "cache_ttl_seconds": REPORTS_CACHE_TTL_SECONDS,
            }
            return result

        issues_payload = self.search_issues(jql=jql, fields=fields)
        issues: list[dict[str, Any]] = list(issues_payload.get("issues") or [])

        issue_keys = [issue.get("key", "") for issue in issues if issue.get("key")]
        issue_keys = issue_keys[:MAX_HISTORY_ISSUES]

        histories = self._fetch_issue_histories(issue_keys)

        heatmap = self._build_heatmap(issues)
        priority_mix = self._build_priority_mix(issues)
        burndown = self._build_burndown(issues, histories)
        due_risk = self._build_due_risk(issues)
        estimate_load = self._build_estimate_load(issues)
        label_hotspots = self._build_label_hotspots(issues)

        result = {
            "jql": jql,
            "fetched_at": datetime.now(timezone.utc).isoformat(),
            "scope": {
                "total_issues": len(issues),
                "issues_with_history": len(histories),
                "history_capped": len(issues) > len(issue_keys),
                "history_cap": MAX_HISTORY_ISSUES,
            },
            "reports": {
                "heatmap": heatmap,
                "burndown": burndown,
                "priority_mix": priority_mix,
                "due_risk": due_risk,
                "estimate_load": estimate_load,
                "label_hotspots": label_hotspots,
            },
            "diagnostics": {
                "cache_hit": False,
                "duration_ms": round((monotonic_time.monotonic() - started) * 1000),
                "history_issues_checked": len(issue_keys),
                "search_cache_hit": bool((issues_payload.get("diagnostics") or {}).get("cache_hit")),
                "cache_ttl_seconds": REPORTS_CACHE_TTL_SECONDS,
            },
        }
        self._cache_set(
            self._reports_cache,
            cache_key,
            result,
            ttl_seconds=REPORTS_CACHE_TTL_SECONDS,
            max_entries=REPORTS_CACHE_MAX_ENTRIES,
        )
        return result

    def get_create_ticket_meta(self, projects: list[str]) -> dict[str, Any]:
        project_keys = [p.strip().upper() for p in projects if p and p.strip()]
        if not project_keys:
            project_keys = ["LDA", "LLAPEX", "DOPP"]

        cache_key = self._projects_cache_key(project_keys)
        cached = self._cache_get(self._create_meta_cache, cache_key)
        if isinstance(cached, dict):
            return cached

        project_clause = (
            f"project = {project_keys[0]}"
            if len(project_keys) == 1
            else "project in (" + ",".join(project_keys) + ")"
        )

        team_members = self._discover_team_members(project_clause)
        labels = self._discover_labels(project_clause)
        sprint_meta = self._discover_sprint_window(project_keys)

        default_user = self.jira_username.strip()
        available_values = {entry.get("value", "") for entry in team_members}
        if default_user and default_user not in available_values:
            team_members.insert(
                0,
                {
                    "label": f"{default_user} (default)",
                    "value": default_user,
                    "display_name": default_user,
                    "email": default_user,
                    "key": "",
                    "account_id": "",
                },
            )

        result = {
            "projects": project_keys,
            "issue_types": ["Task", "Story", "Bug"],
            "priorities": ["Highest", "High", "Medium", "Low", "Lowest"],
            "team_members": team_members,
            "labels": labels,
            "sprints": sprint_meta.get("options", []),
            "board": sprint_meta.get("board"),
            "defaults": {
                "project_key": project_keys[0] if project_keys else "",
                "issue_type": "Task",
                "priority": "Medium",
                "assignee": default_user,
                "reporter": default_user,
                "sprint_id": sprint_meta.get("default_sprint_id", ""),
                "estimate_hours": "",
            },
            "fetched_at": datetime.now(timezone.utc).isoformat(),
        }
        self._cache_set(
            self._create_meta_cache,
            cache_key,
            result,
            ttl_seconds=CREATE_META_CACHE_TTL_SECONDS,
            max_entries=CREATE_META_CACHE_MAX_ENTRIES,
        )
        return result

    def create_ticket(self, payload: dict[str, Any]) -> dict[str, Any]:
        project_key = str(payload.get("project_key") or "").strip().upper()
        issue_type = str(payload.get("issue_type") or "Task").strip() or "Task"
        priority = str(payload.get("priority") or "").strip()
        summary = str(payload.get("summary") or "").strip()
        description = str(payload.get("description") or "").strip()
        assignee = str(payload.get("assignee") or "").strip()
        reporter = str(payload.get("reporter") or "").strip()
        sprint_id = str(payload.get("sprint_id") or "").strip()
        raw_labels = payload.get("labels")
        estimate_hours_raw = payload.get("estimate_hours")

        if not project_key:
            raise ValueError("project_key is required")
        if not summary:
            raise ValueError("summary is required")

        labels: list[str] = []
        if isinstance(raw_labels, list):
            for item in raw_labels:
                label = str(item or "").strip()
                if label:
                    labels.append(label)
        elif isinstance(raw_labels, str):
            labels = [part.strip() for part in raw_labels.split(",") if part.strip()]

        warnings: list[str] = []
        additional_fields: dict[str, Any] = {}
        if labels:
            additional_fields["labels"] = labels
        if priority:
            additional_fields["priority"] = {"name": priority}
        if reporter:
            if reporter.startswith("accountid:"):
                additional_fields["reporter"] = {"accountId": reporter.split(":", 1)[1]}
            elif "@" in reporter:
                additional_fields["reporter"] = {"name": reporter}
            else:
                additional_fields["reporter"] = {"name": reporter}

        create_args: dict[str, Any] = {
            "project_key": project_key,
            "summary": summary,
            "issue_type": issue_type,
            "description": description,
        }
        if assignee:
            create_args["assignee"] = assignee
        if additional_fields:
            create_args["additional_fields"] = json.dumps(additional_fields)

        created_payload: Any
        issue_key: str | None = None

        try:
            created_payload = self.client.call_tool("jira_create_issue", create_args, timeout=180)
            issue_key = self._extract_issue_key(created_payload)
        except Exception as exc:
            if "reporter" in additional_fields:
                warnings.append(
                    "Reporter could not be applied on create with your Jira permissions; "
                    "created without reporter override."
                )
                additional_no_reporter = dict(additional_fields)
                additional_no_reporter.pop("reporter", None)
                retry_args = dict(create_args)
                if additional_no_reporter:
                    retry_args["additional_fields"] = json.dumps(additional_no_reporter)
                else:
                    retry_args.pop("additional_fields", None)
                created_payload = self.client.call_tool("jira_create_issue", retry_args, timeout=180)
                issue_key = self._extract_issue_key(created_payload)
            else:
                raise RuntimeError(f"Failed to create Jira issue: {exc}") from exc

        if not issue_key:
            raise RuntimeError("Issue was created but no issue key was returned")

        if sprint_id:
            try:
                self.client.call_tool(
                    "jira_add_issues_to_sprint",
                    {"sprint_id": sprint_id, "issue_keys": issue_key},
                    timeout=120,
                )
            except Exception as exc:
                warnings.append(f"Ticket created, but sprint assignment failed: {exc}")

        estimate_hours: float | None = None
        if estimate_hours_raw not in (None, ""):
            try:
                estimate_hours = float(estimate_hours_raw)
            except (TypeError, ValueError):
                warnings.append("Estimated hours was not a valid number and was ignored.")

        if estimate_hours is not None and estimate_hours > 0:
            estimate_text = f"{estimate_hours:g}h"
            seconds = int(round(estimate_hours * 3600))
            updated = False
            try:
                self.client.call_tool(
                    "jira_update_issue",
                    {
                        "issue_key": issue_key,
                        "fields": json.dumps(
                            {
                                "timetracking": {
                                    "originalEstimate": estimate_text,
                                    "remainingEstimate": estimate_text,
                                }
                            }
                        ),
                    },
                    timeout=120,
                )
                updated = True
            except Exception:
                pass

            if not updated:
                try:
                    self.client.call_tool(
                        "jira_update_issue",
                        {
                            "issue_key": issue_key,
                            "fields": json.dumps(
                                {
                                    "timeoriginalestimate": seconds,
                                    "timeestimate": seconds,
                                }
                            ),
                        },
                        timeout=120,
                    )
                    updated = True
                except Exception as exc:
                    warnings.append(f"Ticket created, but estimate could not be set: {exc}")

        # A ticket write changed project state; clear short-lived read caches.
        self._invalidate_query_caches()

        return {
            "ok": True,
            "issue_key": issue_key,
            "url": build_jira_url(self.jira_base_url, issue_key),
            "warnings": warnings,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

    def _as_list(self, payload: Any) -> list[Any]:
        # Jira MCP tools may return:
        # - a list directly
        # - a dict with list keys (values/boards/sprints/issues)
        # - a dict with "result" containing a JSON string list
        # Handle all of those robustly.
        stack: list[Any] = [payload]
        visited_ids: set[int] = set()

        while stack:
            current = stack.pop()
            if id(current) in visited_ids:
                continue
            visited_ids.add(id(current))

            if isinstance(current, list):
                return current

            if isinstance(current, str):
                parsed = try_parse_json(current)
                if parsed is not None:
                    stack.append(parsed)
                continue

            if isinstance(current, dict):
                for key in (
                    "values",
                    "boards",
                    "sprints",
                    "issues",
                    "items",
                    "result",
                    "data",
                ):
                    value = current.get(key)
                    if isinstance(value, list):
                        return value
                    if isinstance(value, (dict, str)):
                        stack.append(value)

        return []

    def _search_raw(self, jql: str, fields: list[str], limit: int = 200, max_pages: int = 4) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        start_at = 0

        for _ in range(max_pages):
            payload = self.client.call_tool(
                "jira_search",
                {
                    "jql": jql,
                    "fields": ",".join(fields),
                    "limit": min(PAGE_SIZE, limit),
                    "start_at": start_at,
                },
                timeout=180,
            )
            page = self._normalize_search_payload(payload)
            issues = page.get("issues") if isinstance(page, dict) else None
            if not isinstance(issues, list) or not issues:
                break

            for item in issues:
                if isinstance(item, dict):
                    results.append(item)

            start_at += len(issues)
            if len(results) >= limit:
                break

            raw_total = page.get("total") if isinstance(page, dict) else None
            try:
                total = int(raw_total) if raw_total is not None else None
            except (TypeError, ValueError):
                total = None
            if total is not None and start_at >= total:
                break

        return results[:limit]

    def _discover_team_members(self, project_clause: str) -> list[dict[str, str]]:
        jql = (
            f"{project_clause} AND updated >= -180d "
            "AND (assignee is not EMPTY OR reporter is not EMPTY) "
            "ORDER BY updated DESC"
        )
        issues = self._search_raw(jql=jql, fields=["assignee", "reporter"], limit=300, max_pages=6)

        users_by_value: dict[str, dict[str, str]] = {}

        def add_user(user_obj: Any) -> None:
            if not isinstance(user_obj, dict):
                return
            display_name = (
                user_obj.get("display_name")
                or user_obj.get("displayName")
                or user_obj.get("name")
                or user_obj.get("email")
                or ""
            )
            email = str(user_obj.get("email") or user_obj.get("name") or "").strip()
            key = str(user_obj.get("key") or "").strip()
            account_id = str(user_obj.get("accountId") or user_obj.get("account_id") or "").strip()
            value = email or account_id or key or display_name
            if not value:
                return
            if value in users_by_value:
                return
            label = display_name
            if email and email != display_name:
                label = f"{display_name} ({email})"
            users_by_value[value] = {
                "label": label,
                "value": value,
                "display_name": display_name,
                "email": email,
                "key": key,
                "account_id": account_id,
            }

        for issue in issues:
            add_user(issue.get("assignee"))
            add_user(issue.get("reporter"))
            fields = issue.get("fields")
            if isinstance(fields, dict):
                add_user(fields.get("assignee"))
                add_user(fields.get("reporter"))

        members = list(users_by_value.values())
        members.sort(key=lambda item: (item.get("display_name") or item.get("label") or "").lower())
        return members

    def _discover_labels(self, project_clause: str) -> list[str]:
        jql = f"{project_clause} AND labels is not EMPTY ORDER BY updated DESC"
        issues = self._search_raw(jql=jql, fields=["labels"], limit=400, max_pages=8)
        label_set: set[str] = set()

        for issue in issues:
            raw_labels = issue.get("labels")
            if raw_labels is None:
                fields = issue.get("fields")
                if isinstance(fields, dict):
                    raw_labels = fields.get("labels")
            if not isinstance(raw_labels, list):
                continue
            for label in raw_labels:
                normalized = str(label or "").strip()
                if normalized:
                    label_set.add(normalized)

        if not label_set:
            return []

        preferred = sorted([label for label in label_set if label.startswith("LiveLabs-")], key=str.lower)
        if preferred:
            return preferred
        return sorted(label_set, key=str.lower)

    def _discover_sprint_window(self, projects: list[str]) -> dict[str, Any]:
        boards: list[dict[str, Any]] = []

        for project in projects:
            payload = self.client.call_tool(
                "jira_get_agile_boards",
                {"project_key": project, "board_type": "scrum", "limit": 20},
                timeout=120,
            )
            for board in self._as_list(payload):
                if isinstance(board, dict) and board.get("id"):
                    boards.append(board)

        if not boards:
            payload = self.client.call_tool(
                "jira_get_agile_boards",
                {"board_type": "scrum", "limit": 20},
                timeout=120,
            )
            for board in self._as_list(payload):
                if isinstance(board, dict) and board.get("id"):
                    boards.append(board)

        # Deduplicate board IDs.
        dedup: dict[str, dict[str, Any]] = {}
        for board in boards:
            board_id = str(board.get("id"))
            dedup.setdefault(board_id, board)
        boards = list(dedup.values())

        chosen_board: dict[str, Any] | None = None
        active_sprints: list[dict[str, Any]] = []

        for board in boards:
            board_id = str(board.get("id") or "")
            if not board_id:
                continue
            payload = self.client.call_tool(
                "jira_get_sprints_from_board",
                {"board_id": board_id, "state": "active", "limit": 10},
                timeout=120,
            )
            active = [item for item in self._as_list(payload) if isinstance(item, dict)]
            if active:
                chosen_board = board
                active_sprints = active
                break

        if chosen_board is None and boards:
            chosen_board = boards[0]
            board_id = str(chosen_board.get("id") or "")
            payload = self.client.call_tool(
                "jira_get_sprints_from_board",
                {"board_id": board_id, "state": "active", "limit": 10},
                timeout=120,
            )
            active_sprints = [item for item in self._as_list(payload) if isinstance(item, dict)]

        if chosen_board is None:
            return {"options": [], "default_sprint_id": "", "board": None}

        board_id = str(chosen_board.get("id") or "")
        future_payload = self.client.call_tool(
            "jira_get_sprints_from_board",
            {"board_id": board_id, "state": "future", "limit": 50},
            timeout=120,
        )
        closed_payload = self.client.call_tool(
            "jira_get_sprints_from_board",
            {"board_id": board_id, "state": "closed", "limit": 50},
            timeout=120,
        )
        future_sprints = [item for item in self._as_list(future_payload) if isinstance(item, dict)]
        closed_sprints = [item for item in self._as_list(closed_payload) if isinstance(item, dict)]

        def sprint_start(item: dict[str, Any]) -> datetime | None:
            return parse_datetime_safe(item.get("start_date") or item.get("startDate"))

        def sprint_end(item: dict[str, Any]) -> datetime | None:
            return parse_datetime_safe(item.get("end_date") or item.get("endDate"))

        current: dict[str, Any] | None = None
        if active_sprints:
            active_sorted = sorted(active_sprints, key=lambda s: sprint_start(s) or datetime.max.replace(tzinfo=timezone.utc))
            current = active_sorted[0]

        previous: dict[str, Any] | None = None
        nxt: dict[str, Any] | None = None

        if current is not None:
            current_start = sprint_start(current)
            current_end = sprint_end(current)

            closed_with_end = []
            for item in closed_sprints:
                end_val = sprint_end(item)
                if end_val is not None:
                    closed_with_end.append((end_val, item))
            if current_start is not None:
                candidates = [pair for pair in closed_with_end if pair[0] <= current_start]
                if candidates:
                    previous = sorted(candidates, key=lambda pair: pair[0], reverse=True)[0][1]
            if previous is None and closed_with_end:
                previous = sorted(closed_with_end, key=lambda pair: pair[0], reverse=True)[0][1]

            future_with_start = []
            for item in future_sprints:
                start_val = sprint_start(item)
                if start_val is not None:
                    future_with_start.append((start_val, item))
            if current_end is not None:
                candidates = [pair for pair in future_with_start if pair[0] >= current_end]
                if candidates:
                    nxt = sorted(candidates, key=lambda pair: pair[0])[0][1]
            if nxt is None and future_with_start:
                nxt = sorted(future_with_start, key=lambda pair: pair[0])[0][1]
            if nxt is None and future_sprints:
                nxt = future_sprints[0]
        else:
            if closed_sprints:
                closed_sorted = sorted(
                    closed_sprints,
                    key=lambda s: sprint_end(s) or datetime.min.replace(tzinfo=timezone.utc),
                    reverse=True,
                )
                previous = closed_sorted[0]
            if future_sprints:
                future_sorted = sorted(
                    future_sprints,
                    key=lambda s: sprint_start(s) or datetime.max.replace(tzinfo=timezone.utc),
                )
                current = future_sorted[0]
                if len(future_sorted) > 1:
                    nxt = future_sorted[1]

        options: list[dict[str, str]] = []
        seen_ids: set[str] = set()

        def add_option(item: dict[str, Any] | None, prefix: str) -> None:
            if not isinstance(item, dict):
                return
            sprint_id = str(item.get("id") or "").strip()
            name = str(item.get("name") or "").strip()
            state = str(item.get("state") or "").strip()
            if not sprint_id or sprint_id in seen_ids:
                return
            seen_ids.add(sprint_id)
            label = f"{prefix} - {name}" if prefix else name
            options.append(
                {
                    "id": sprint_id,
                    "name": name,
                    "state": state,
                    "label": label,
                }
            )

        add_option(previous, "-1 Previous")
        add_option(current, "Current")
        add_option(nxt, "+1 Next")

        default_sprint_id = ""
        if current and current.get("id"):
            default_sprint_id = str(current.get("id"))
        elif options:
            default_sprint_id = options[0]["id"]

        return {
            "options": options,
            "default_sprint_id": default_sprint_id,
            "board": {
                "id": str(chosen_board.get("id") or ""),
                "name": str(chosen_board.get("name") or ""),
            },
        }

    def _extract_issue_key(self, payload: Any) -> str | None:
        if isinstance(payload, dict):
            for key_name in ("key", "issue_key", "issueKey"):
                value = payload.get(key_name)
                if isinstance(value, str) and value.strip():
                    return value.strip()
            for nested_key in ("issue", "result"):
                nested = payload.get(nested_key)
                extracted = self._extract_issue_key(nested)
                if extracted:
                    return extracted
            issues = payload.get("issues")
            if isinstance(issues, list) and issues:
                extracted = self._extract_issue_key(issues[0])
                if extracted:
                    return extracted
        if isinstance(payload, list) and payload:
            for item in payload:
                extracted = self._extract_issue_key(item)
                if extracted:
                    return extracted
        if isinstance(payload, str):
            parsed = try_parse_json(payload)
            if parsed is not None:
                return self._extract_issue_key(parsed)
            # Last resort: detect ABC-123 style key
            match = re.search(r"\b[A-Z][A-Z0-9]+-\d+\b", payload)
            if match:
                return match.group(0)
        return None

    def _fetch_issue_histories(self, issue_keys: list[str]) -> dict[str, dict[str, Any]]:
        histories: dict[str, dict[str, Any]] = {}
        if not issue_keys:
            return histories

        normalized_keys: list[str] = []
        for raw_key in issue_keys:
            key = str(raw_key or "").strip().upper()
            if key:
                normalized_keys.append(key)
        if not normalized_keys:
            return histories

        missing_keys: list[str] = []
        for issue_key in normalized_keys:
            cached = self._cache_get(self._history_cache, issue_key)
            if isinstance(cached, dict):
                histories[issue_key] = cached
            else:
                missing_keys.append(issue_key)

        if not missing_keys:
            return histories

        def worker(issue_key: str) -> tuple[str, dict[str, Any] | None]:
            payload = self.client.call_tool(
                "jira_get_issue_dates",
                {
                    "issue_key": issue_key,
                    "include_status_changes": True,
                    "include_status_summary": True,
                },
                timeout=180,
            )
            normalized = self._normalize_issue_dates_payload(payload)
            return issue_key, normalized

        unique_missing_keys = sorted(set(missing_keys))
        max_workers = max(1, min(8, len(unique_missing_keys)))
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [executor.submit(worker, key) for key in unique_missing_keys]
            for future in concurrent.futures.as_completed(futures):
                try:
                    issue_key, payload = future.result()
                except Exception:
                    continue
                if isinstance(payload, dict):
                    histories[issue_key] = payload
                    self._cache_set(
                        self._history_cache,
                        issue_key,
                        payload,
                        ttl_seconds=HISTORY_CACHE_TTL_SECONDS,
                        max_entries=HISTORY_CACHE_MAX_ENTRIES,
                    )

        return histories

    def _normalize_issue_dates_payload(self, payload: Any) -> dict[str, Any] | None:
        if isinstance(payload, dict):
            if payload.get("issue_key"):
                return payload
            if "result" in payload:
                inner = payload["result"]
                if isinstance(inner, dict):
                    return inner
                if isinstance(inner, str):
                    parsed = try_parse_json(inner)
                    if isinstance(parsed, dict):
                        return parsed
            return payload
        if isinstance(payload, str):
            parsed = try_parse_json(payload)
            if isinstance(parsed, dict):
                return parsed
        return None

    def _build_heatmap(self, issues: list[dict[str, Any]]) -> dict[str, Any]:
        buckets = ["To Do", "In Progress", "Blocked / On Hold", "Done"]
        by_assignee: dict[str, dict[str, int]] = {}

        for issue in issues:
            assignee = issue.get("assignee") or "Unassigned"
            bucket = status_bucket(issue.get("status", ""))
            row = by_assignee.setdefault(assignee, {name: 0 for name in buckets})
            row[bucket] = row.get(bucket, 0) + 1

        rows = []
        for assignee, counts in sorted(by_assignee.items(), key=lambda item: sum(item[1].values()), reverse=True):
            total = sum(counts.values())
            rows.append(
                {
                    "assignee": assignee,
                    "counts": counts,
                    "total": total,
                }
            )

        return {
            "buckets": buckets,
            "rows": rows,
        }

    def _build_priority_mix(self, issues: list[dict[str, Any]]) -> dict[str, Any]:
        priorities = ["Highest", "High", "Medium", "Low", "Lowest", "None"]
        by_assignee: dict[str, dict[str, int]] = {}

        for issue in issues:
            assignee = issue.get("assignee") or "Unassigned"
            priority = (issue.get("priority") or "None").strip() or "None"
            if priority not in priorities:
                priority = "None"
            row = by_assignee.setdefault(assignee, {name: 0 for name in priorities})
            row[priority] = row.get(priority, 0) + 1

        rows = []
        for assignee, counts in sorted(by_assignee.items(), key=lambda item: sum(item[1].values()), reverse=True):
            total = sum(counts.values())
            rows.append(
                {
                    "assignee": assignee,
                    "counts": counts,
                    "total": total,
                }
            )

        return {"priorities": priorities, "rows": rows}

    def _build_due_risk(self, issues: list[dict[str, Any]]) -> dict[str, Any]:
        today = datetime.now(timezone.utc).date()
        summary = {
            "overdue": 0,
            "due_today": 0,
            "due_next_7_days": 0,
            "due_later": 0,
            "no_due_date": 0,
        }

        overdue_rows: list[dict[str, Any]] = []
        upcoming_rows: list[dict[str, Any]] = []

        for issue in issues:
            due_dt = parse_datetime_safe(issue.get("duedate"))
            if not due_dt:
                summary["no_due_date"] += 1
                continue

            due_date = due_dt.astimezone(timezone.utc).date()
            delta_days = (due_date - today).days

            if delta_days < 0:
                summary["overdue"] += 1
                overdue_rows.append(
                    {
                        "key": issue.get("key", ""),
                        "url": issue.get("url") or build_jira_url(self.jira_base_url, str(issue.get("key") or "")),
                        "summary": issue.get("summary", ""),
                        "assignee": issue.get("assignee") or "Unassigned",
                        "status": issue.get("status", ""),
                        "priority": issue.get("priority", ""),
                        "due_date": due_date.isoformat(),
                        "days_overdue": abs(delta_days),
                    }
                )
            elif delta_days == 0:
                summary["due_today"] += 1
                upcoming_rows.append(
                    {
                        "key": issue.get("key", ""),
                        "url": issue.get("url") or build_jira_url(self.jira_base_url, str(issue.get("key") or "")),
                        "summary": issue.get("summary", ""),
                        "assignee": issue.get("assignee") or "Unassigned",
                        "status": issue.get("status", ""),
                        "priority": issue.get("priority", ""),
                        "due_date": due_date.isoformat(),
                        "days_until_due": 0,
                    }
                )
            elif delta_days <= 7:
                summary["due_next_7_days"] += 1
                upcoming_rows.append(
                    {
                        "key": issue.get("key", ""),
                        "url": issue.get("url") or build_jira_url(self.jira_base_url, str(issue.get("key") or "")),
                        "summary": issue.get("summary", ""),
                        "assignee": issue.get("assignee") or "Unassigned",
                        "status": issue.get("status", ""),
                        "priority": issue.get("priority", ""),
                        "due_date": due_date.isoformat(),
                        "days_until_due": delta_days,
                    }
                )
            else:
                summary["due_later"] += 1

        overdue_rows.sort(key=lambda row: int(row.get("days_overdue") or 0), reverse=True)
        upcoming_rows.sort(key=lambda row: int(row.get("days_until_due") or 0))

        return {
            "summary": summary,
            "overdue_rows": overdue_rows[:12],
            "upcoming_rows": upcoming_rows[:12],
        }

    def _build_estimate_load(self, issues: list[dict[str, Any]]) -> dict[str, Any]:
        by_assignee: dict[str, dict[str, Any]] = {}
        total_estimated_seconds = 0
        total_unestimated = 0

        for issue in issues:
            assignee = issue.get("assignee") or "Unassigned"
            row = by_assignee.setdefault(
                assignee,
                {
                    "assignee": assignee,
                    "issue_count": 0,
                    "estimated_issue_count": 0,
                    "unestimated_issue_count": 0,
                    "total_estimate_seconds": 0,
                },
            )
            row["issue_count"] += 1

            estimate_seconds = int_or_none(issue.get("effective_estimate_seconds"))
            if estimate_seconds is None:
                row["unestimated_issue_count"] += 1
                total_unestimated += 1
                continue

            row["estimated_issue_count"] += 1
            row["total_estimate_seconds"] += estimate_seconds
            total_estimated_seconds += estimate_seconds

        rows = sorted(
            by_assignee.values(),
            key=lambda item: (int(item.get("total_estimate_seconds") or 0), int(item.get("issue_count") or 0)),
            reverse=True,
        )

        for row in rows:
            total_seconds = int(row.get("total_estimate_seconds") or 0)
            estimated_count = int(row.get("estimated_issue_count") or 0)
            row["total_estimate_hours"] = round(total_seconds / 3600, 2)
            row["avg_estimate_hours"] = round((total_seconds / estimated_count) / 3600, 2) if estimated_count else 0.0

        return {
            "summary": {
                "total_estimated_hours": round(total_estimated_seconds / 3600, 2),
                "unestimated_issues": total_unestimated,
            },
            "rows": rows[:20],
        }

    def _build_label_hotspots(self, issues: list[dict[str, Any]]) -> dict[str, Any]:
        by_label: dict[str, dict[str, Any]] = {}
        unlabeled_issue_count = 0

        for issue in issues:
            labels = issue.get("labels")
            if not isinstance(labels, list):
                labels = []

            valid_labels = [str(label).strip() for label in labels if str(label).strip()]
            bucket = status_bucket(issue.get("status", ""))

            if not valid_labels:
                unlabeled_issue_count += 1
                continue

            for label in valid_labels:
                row = by_label.setdefault(
                    label,
                    {
                        "label": label,
                        "total": 0,
                        "todo": 0,
                        "in_progress": 0,
                        "blocked": 0,
                        "done": 0,
                    },
                )
                row["total"] += 1
                if bucket == "In Progress":
                    row["in_progress"] += 1
                elif bucket == "Blocked / On Hold":
                    row["blocked"] += 1
                elif bucket == "Done":
                    row["done"] += 1
                else:
                    row["todo"] += 1

        rows = sorted(by_label.values(), key=lambda item: int(item.get("total") or 0), reverse=True)

        return {
            "summary": {
                "distinct_labels": len(by_label),
                "unlabeled_issues": unlabeled_issue_count,
            },
            "rows": rows[:20],
        }

    def _build_burndown(self, issues: list[dict[str, Any]], histories: dict[str, dict[str, Any]]) -> dict[str, Any]:
        if not issues:
            return {
                "series": [],
                "summary": {
                    "initial_scope": 0,
                    "remaining": 0,
                    "completed": 0,
                    "trend": "flat",
                },
            }

        created_times: dict[str, datetime] = {}
        completed_times: dict[str, datetime] = {}

        for issue in issues:
            key = issue.get("key", "")
            history = histories.get(key, {})

            created_dt = parse_datetime_safe(history.get("created")) or parse_datetime_safe(issue.get("updated"))
            if created_dt:
                created_times[key] = created_dt.astimezone(timezone.utc)

            done_dt = self._extract_done_datetime(history, issue)
            if done_dt:
                completed_times[key] = done_dt.astimezone(timezone.utc)

        now_utc = datetime.now(timezone.utc)
        if created_times:
            first_day = min(dt.date() for dt in created_times.values())
        else:
            first_day = (now_utc - timedelta(days=13)).date()

        last_day = now_utc.date()
        if first_day > last_day:
            first_day = last_day

        max_start = last_day - timedelta(days=MAX_BURNDOWN_DAYS - 1)
        if first_day < max_start:
            first_day = max_start

        days = (last_day - first_day).days + 1
        series: list[dict[str, Any]] = []

        for offset in range(days):
            day = first_day + timedelta(days=offset)
            day_end = datetime.combine(day, time.max, tzinfo=timezone.utc)

            in_scope = 0
            completed = 0
            remaining = 0

            for issue in issues:
                key = issue.get("key", "")
                created_dt = created_times.get(key)
                if created_dt and created_dt <= day_end:
                    in_scope += 1
                elif created_dt is None:
                    in_scope += 1

                done_dt = completed_times.get(key)
                if done_dt and done_dt <= day_end:
                    completed += 1

            remaining = max(0, in_scope - completed)

            series.append(
                {
                    "date": day.isoformat(),
                    "in_scope": in_scope,
                    "completed": completed,
                    "remaining": remaining,
                }
            )

        initial_scope = series[0]["in_scope"] if series else len(issues)
        final_remaining = series[-1]["remaining"] if series else len(issues)
        final_completed = series[-1]["completed"] if series else 0

        trend = "flat"
        if len(series) >= 2:
            if series[-1]["remaining"] < series[0]["remaining"]:
                trend = "down"
            elif series[-1]["remaining"] > series[0]["remaining"]:
                trend = "up"

        return {
            "series": series,
            "summary": {
                "initial_scope": initial_scope,
                "remaining": final_remaining,
                "completed": final_completed,
                "trend": trend,
                "date_start": series[0]["date"] if series else "",
                "date_end": series[-1]["date"] if series else "",
            },
        }

    def _extract_done_datetime(self, history: dict[str, Any], issue: dict[str, Any]) -> datetime | None:
        resolution_dt = parse_datetime_safe(history.get("resolution_date"))
        if resolution_dt:
            return resolution_dt

        changes = history.get("status_changes")
        if isinstance(changes, list):
            for change in changes:
                if not isinstance(change, dict):
                    continue
                status_name = str(change.get("status") or "").strip().lower()
                if status_name in DONE_STATUS_NAMES or any(marker in status_name for marker in DONE_STATUS_NAMES):
                    entered_at = parse_datetime_safe(change.get("entered_at"))
                    if entered_at:
                        return entered_at

        current_status = str(issue.get("status") or "").strip().lower()
        if current_status in DONE_STATUS_NAMES or any(marker in current_status for marker in DONE_STATUS_NAMES):
            return parse_datetime_safe(issue.get("updated"))

        return None

    def _normalize_search_payload(self, payload: Any) -> dict[str, Any]:
        if isinstance(payload, dict):
            if "issues" in payload:
                return payload
            if "result" in payload and isinstance(payload["result"], (str, dict)):
                inner = payload["result"]
                if isinstance(inner, dict):
                    return inner
                parsed = try_parse_json(inner)
                if isinstance(parsed, dict):
                    return parsed
            return payload

        if isinstance(payload, str):
            parsed = try_parse_json(payload)
            if isinstance(parsed, dict):
                return parsed

        return {"issues": []}

    def _normalize_issue(self, issue: Any) -> dict[str, Any]:
        if not isinstance(issue, dict):
            return {
                "key": "",
                "summary": str(issue),
                "status": "",
                "status_category": "",
                "priority": "",
                "assignee": "",
                "reporter": "",
                "labels": [],
                "updated": "",
                "duedate": "",
                "sprint": "",
                "url": "",
            }

        fields = issue.get("fields") if isinstance(issue.get("fields"), dict) else {}

        key = str(issue.get("key") or "")
        summary = issue.get("summary") or fields.get("summary") or ""

        status_obj = issue.get("status") or fields.get("status") or {}
        priority_obj = issue.get("priority") or fields.get("priority") or {}
        assignee_obj = issue.get("assignee") or fields.get("assignee") or {}
        reporter_obj = issue.get("reporter") or fields.get("reporter") or {}

        labels = issue.get("labels")
        if labels is None:
            labels = fields.get("labels")
        if not isinstance(labels, list):
            labels = []

        updated = issue.get("updated") or fields.get("updated") or ""
        due_date = issue.get("duedate") or fields.get("duedate") or ""
        sprint_name = extract_sprint_name(issue.get("sprint") or fields.get("sprint"))
        timetracking_obj = issue.get("timetracking")
        if timetracking_obj is None:
            timetracking_obj = fields.get("timetracking")
        if not isinstance(timetracking_obj, dict):
            timetracking_obj = {}

        remaining_estimate_text = (
            timetracking_obj.get("remaining_estimate")
            or timetracking_obj.get("remainingEstimate")
            or ""
        )
        original_estimate_text = (
            timetracking_obj.get("original_estimate")
            or timetracking_obj.get("originalEstimate")
            or ""
        )

        remaining_estimate_seconds = int_or_none(
            issue.get("timeestimate")
            if issue.get("timeestimate") is not None
            else fields.get("timeestimate")
        )
        original_estimate_seconds = int_or_none(
            issue.get("timeoriginalestimate")
            if issue.get("timeoriginalestimate") is not None
            else fields.get("timeoriginalestimate")
        )
        effective_estimate_seconds = (
            remaining_estimate_seconds
            if remaining_estimate_seconds is not None
            else original_estimate_seconds
        )

        # Fallback for Jira responses that only include timetracking text (e.g. "20h", "1h 30m").
        if remaining_estimate_seconds is None:
            remaining_estimate_seconds = parse_estimate_text_to_seconds(remaining_estimate_text)
        if original_estimate_seconds is None:
            original_estimate_seconds = parse_estimate_text_to_seconds(original_estimate_text)
        if effective_estimate_seconds is None:
            effective_estimate_seconds = (
                remaining_estimate_seconds
                if remaining_estimate_seconds is not None
                else original_estimate_seconds
            )

        status_name = ""
        if isinstance(status_obj, dict):
            status_name = status_obj.get("name") or ""

        priority_name = ""
        if isinstance(priority_obj, dict):
            priority_name = priority_obj.get("name") or ""

        return {
            "key": key,
            "summary": str(summary),
            "status": status_name,
            "status_category": extract_status_category(status_obj),
            "priority": priority_name,
            "assignee": pick_display_name(assignee_obj),
            "reporter": pick_display_name(reporter_obj),
            "labels": labels,
            "updated": str(updated) if updated else "",
            "duedate": str(due_date) if due_date else "",
            "sprint": sprint_name,
            "remaining_estimate_seconds": remaining_estimate_seconds,
            "original_estimate_seconds": original_estimate_seconds,
            "effective_estimate_seconds": effective_estimate_seconds,
            "remaining_estimate_text": str(remaining_estimate_text) if remaining_estimate_text else "",
            "original_estimate_text": str(original_estimate_text) if original_estimate_text else "",
            "url": build_jira_url(self.jira_base_url, key),
        }


class DashboardHTTPServer(ThreadingHTTPServer):
    def server_bind(self) -> None:
        TCPServer.server_bind(self)
        host, port = self.server_address[:2]
        self.server_name = str(host or "localhost")
        self.server_port = int(port)

    def __init__(
        self,
        server_address: tuple[str, int],
        request_handler_class: type[BaseHTTPRequestHandler],
        bridge: JiraDashboardBridge,
        default_projects: list[str],
        app_version: str,
        update_source_url: str,
    ) -> None:
        super().__init__(server_address, request_handler_class)
        self.bridge = bridge
        self.default_projects = default_projects
        self.app_version = app_version
        self.update_source_url = update_source_url


class DashboardHandler(BaseHTTPRequestHandler):
    server: DashboardHTTPServer

    def log_message(self, fmt: str, *args: Any) -> None:
        timestamp = datetime.now().strftime("%H:%M:%S")
        print(f"[{timestamp}] {self.address_string()} - {fmt % args}")

    def _send_json(self, payload: dict[str, Any], status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_file(self, path: Path, content_type: str) -> None:
        if not path.exists():
            self.send_error(404)
            return

        data = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    @staticmethod
    def _normalize_route_path(path: str) -> str:
        direct_paths = {
            "/",
            "/index.html",
            "/README.md",
            "/release-notes",
            "/api/health",
            "/api/tickets",
            "/api/reports",
            "/api/create-ticket/meta",
            "/api/create-ticket",
            "/api/open-url",
        }
        if path in direct_paths:
            return path

        suffix_paths = (
            "/index.html",
            "/README.md",
            "/release-notes",
            "/api/health",
            "/api/tickets",
            "/api/reports",
            "/api/create-ticket/meta",
            "/api/create-ticket",
            "/api/open-url",
        )
        for suffix in suffix_paths:
            if path.endswith(suffix):
                return suffix

        if path.endswith("/") and path != "/":
            return "/index.html"
        return path

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        route_path = self._normalize_route_path(parsed.path)

        if route_path in ("/", "/index.html"):
            self._send_file(Path(__file__).with_name("index.html"), "text/html; charset=utf-8")
            return

        if route_path in ("/README.md", "/release-notes"):
            self._send_file(Path(__file__).with_name("README.md"), "text/markdown; charset=utf-8")
            return

        if route_path == "/api/health":
            query = parse_qs(parsed.query)
            full = (query.get("full", ["0"])[0] or "0") == "1"

            try:
                if full:
                    self.server.bridge.ensure_ready()
                self._send_json(
                    {
                        "status": "ok",
                        "mcp_connected": self.server.bridge.client.started,
                        "available_tools": self.server.bridge.client.tool_names,
                        "jira_base_url": self.server.bridge.jira_base_url,
                        "open_url_supported": True,
                    }
                )
            except Exception as exc:
                self._send_json(
                    {
                        "status": "error",
                        "error": str(exc),
                        "hint": "Make sure you are on VPN and restart your Codex session if needed.",
                    },
                    status=500,
                )
            return

        if route_path == "/api/tickets":
            self._handle_tickets(parsed.query)
            return

        if route_path == "/api/reports":
            self._handle_reports(parsed.query)
            return

        if route_path == "/api/create-ticket/meta":
            self._handle_create_ticket_meta(parsed.query)
            return

        # Version checking endpoint temporarily disabled.
        # if parsed.path == "/api/version-check":
        #     self._handle_version_check()
        #     return

        self.send_error(404, "Not Found")

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        route_path = self._normalize_route_path(parsed.path)

        if route_path == "/api/create-ticket":
            self._handle_create_ticket()
            return

        if route_path == "/api/open-url":
            self._handle_open_url()
            return

        self.send_error(404, "Not Found")

    def _read_json_body(self) -> dict[str, Any]:
        length_raw = self.headers.get("Content-Length")
        try:
            length = int(length_raw or "0")
        except ValueError:
            length = 0
        if length <= 0:
            return {}
        body = self.rfile.read(length)
        if not body:
            return {}
        try:
            parsed = json.loads(body.decode("utf-8"))
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError:
            pass
        return {}

    def _build_jql_from_query(self, query: str) -> str:
        params = parse_qs(query)

        include_done = (params.get("include_done", ["0"])[0] or "0") in ("1", "true", "yes")
        updated_since = (params.get("updated_since", [""])[0] or "").strip()

        members = split_csv(params.get("members", [""])[0])
        projects = split_csv(params.get("projects", [""])[0])
        if not projects:
            projects = self.server.default_projects

        custom_jql = (params.get("jql", [""])[0] or "").strip()

        if custom_jql:
            jql = custom_jql
        else:
            clauses: list[str] = []

            if projects:
                if len(projects) == 1:
                    clauses.append(f"project = {projects[0]}")
                else:
                    clauses.append("project in (" + ",".join(projects) + ")")

            clauses.append("sprint in openSprints()")

            if members:
                quoted = ",".join(jql_quote(member) for member in members)
                clauses.append(f"assignee in ({quoted})")

            if not include_done and not updated_since:
                clauses.append("status != Closed")

            jql = " AND ".join(clauses) + " ORDER BY priority DESC, duedate ASC, updated DESC"

        if updated_since:
            jira_since = format_jira_datetime_for_jql(updated_since)
            if jira_since:
                jql = append_jql_clause(jql, f'updated >= "{jira_since}"')

        return jql

    def _handle_tickets(self, query: str) -> None:
        jql = self._build_jql_from_query(query)

        fields = [
            "summary",
            "status",
            "priority",
            "assignee",
            "reporter",
            "labels",
            "updated",
            "duedate",
            "sprint",
            "timetracking",
            "timeestimate",
            "timeoriginalestimate",
        ]

        try:
            result = self.server.bridge.search_issues(jql=jql, fields=fields)
            self._send_json(result)
        except Exception as exc:
            self._send_json(
                {
                    "error": str(exc),
                    "hint": "Make sure you are on VPN and restart your Codex session if needed.",
                    "jql": jql,
                },
                status=500,
            )

    def _handle_reports(self, query: str) -> None:
        jql = self._build_jql_from_query(query)

        fields = [
            "summary",
            "status",
            "priority",
            "assignee",
            "reporter",
            "labels",
            "updated",
            "duedate",
            "sprint",
            "timetracking",
            "timeestimate",
            "timeoriginalestimate",
        ]

        try:
            result = self.server.bridge.build_reports(jql=jql, fields=fields)
            self._send_json(result)
        except Exception as exc:
            self._send_json(
                {
                    "error": str(exc),
                    "hint": "Make sure you are on VPN and restart your Codex session if needed.",
                    "jql": jql,
                },
                status=500,
            )

    def _handle_create_ticket_meta(self, query: str) -> None:
        params = parse_qs(query)
        projects = split_csv(params.get("projects", [""])[0])
        if not projects:
            projects = self.server.default_projects
        try:
            result = self.server.bridge.get_create_ticket_meta(projects=projects)
            self._send_json(result)
        except Exception as exc:
            self._send_json(
                {
                    "error": str(exc),
                    "hint": "Make sure you are on VPN and restart your Codex session if needed.",
                },
                status=500,
            )

    def _handle_create_ticket(self) -> None:
        payload = self._read_json_body()
        if not payload:
            self._send_json({"error": "Request body must be valid JSON"}, status=400)
            return

        try:
            result = self.server.bridge.create_ticket(payload)
            self._send_json(result, status=201)
        except ValueError as exc:
            self._send_json(
                {
                    "ok": False,
                    "error": str(exc),
                    "hint": "Please fill in required fields and try again.",
                },
                status=400,
            )
        except Exception as exc:
            self._send_json(
                {
                    "ok": False,
                    "error": str(exc),
                    "hint": "Create failed. Check required fields and Jira permissions.",
                },
                status=500,
            )

    def _handle_open_url(self) -> None:
        payload = self._read_json_body()
        raw_url = str(payload.get("url") or "").strip()
        if not raw_url:
            self._send_json({"ok": False, "error": "Missing URL"}, status=400)
            return

        parsed = urlparse(raw_url)
        host = (parsed.hostname or "").lower()
        allowed_hosts = (
            host == "jira.oraclecorp.com"
            or host.endswith(".oraclecorp.com")
            or host == "oraclecorp.com"
            or host.endswith(".oracle.com")
            or host == "oracle.com"
        )
        if parsed.scheme != "https" or not allowed_hosts:
            self._send_json(
                {
                    "ok": False,
                    "error": "Only HTTPS Oracle/Jira URLs can be opened from this dashboard.",
                },
                status=400,
            )
            return

        try:
            if sys.platform == "darwin" and Path("/usr/bin/open").exists():
                subprocess.Popen(
                    ["/usr/bin/open", raw_url],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True,
                )
            else:
                webbrowser.open_new_tab(raw_url)
            self._send_json({"ok": True, "url": raw_url})
        except Exception as exc:
            self._send_json(
                {
                    "ok": False,
                    "error": str(exc),
                    "hint": "Copy the Jira link and open it in your browser.",
                },
                status=500,
            )

    def _handle_version_check(self) -> None:
        current_version = self.server.app_version or "v0"
        source_url = self.server.update_source_url or ""
        result: dict[str, Any] = {
            "ok": True,
            "current_version": current_version,
            "latest_version": current_version,
            "update_available": False,
            "source_url": source_url,
            "checked_at": datetime.now(timezone.utc).isoformat(),
        }

        if not source_url:
            result["ok"] = False
            result["error"] = "No update source URL configured."
            result["hint"] = "Set JIRAPAT_UPDATE_SOURCE_URL and restart the dashboard server."
            self._send_json(result)
            return

        try:
            future = VERSION_CHECK_EXECUTOR.submit(fetch_update_source_snapshot, source_url)
            try:
                body, content_type = future.result(timeout=18)
            except concurrent.futures.TimeoutError:
                future.cancel()
                result["ok"] = False
                result["error"] = "Version check timed out while contacting the update source."
                result["hint"] = "Check VPN connectivity and make sure the SharePoint folder is reachable."
                self._send_json(result)
                return

            unique_versions = extract_distribution_versions(body)

            if not unique_versions:
                result["ok"] = False
                result["error"] = (
                    "Could not find distribution filenames in the update source response."
                )
                result["hint"] = (
                    "Ensure the SharePoint folder is accessible and contains files named "
                    "like JiraPat-dashboard-distribution-v9.zip."
                )
                result["content_type"] = content_type
                self._send_json(result)
                return

            current_version_number = parse_version_number(current_version)
            latest_version_number = unique_versions[-1]
            latest_version = f"v{latest_version_number}"

            result["latest_version"] = latest_version
            result["matched_versions"] = [f"v{value}" for value in unique_versions]
            if current_version_number is not None:
                result["update_available"] = latest_version_number > current_version_number
            else:
                result["update_available"] = latest_version != current_version
            if result["update_available"]:
                result["download_url"] = source_url

            self._send_json(result)
        except Exception as exc:
            result["ok"] = False
            result["error"] = str(exc)
            result["hint"] = "Check VPN connectivity and verify the update directory URL is reachable."
            self._send_json(result)


def build_default_projects(mcp_config: MCPServerConfig) -> list[str]:
    env_override = os.environ.get("SPRINT_SIGNAL_DEFAULT_PROJECTS", "") or os.environ.get(
        "JIRAPAT_DEFAULT_PROJECTS", ""
    )
    if env_override.strip():
        return split_csv(env_override)

    from_mcp_env = mcp_config.env.get("JIRA_PROJECTS_FILTER", "")
    if from_mcp_env.strip():
        return split_csv(from_mcp_env)

    return ["LLAPEX", "LDA", "SEE", "DOPP"]


def main() -> None:
    parser = argparse.ArgumentParser(description="Outbound PM Operations Dashboard server")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=8765, help="Port to bind (default: 8765)")
    parser.add_argument(
        "--suppress-insecure-warning",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Suppress InsecureRequestWarning lines from MCP stderr (default: enabled)",
    )
    args = parser.parse_args()

    mcp_config = load_mcp_server_config("mcp-atlassian")
    bridge = JiraDashboardBridge(
        mcp_config,
        suppress_insecure_warning=args.suppress_insecure_warning,
    )
    default_projects = build_default_projects(mcp_config)

    server = DashboardHTTPServer(
        (args.host, args.port),
        DashboardHandler,
        bridge=bridge,
        default_projects=default_projects,
        app_version=APP_VERSION,
        update_source_url=DEFAULT_UPDATE_SOURCE_URL,
    )

    print("Outbound PM Operations Dashboard")
    print(f"URL: http://{args.host}:{args.port}")
    print(f"App version: {APP_VERSION}")
    print(f"Default projects: {', '.join(default_projects) if default_projects else '(none)'}")
    print(
        "Cache TTLs (seconds): "
        f"search={SEARCH_CACHE_TTL_SECONDS:g}, "
        f"reports={REPORTS_CACHE_TTL_SECONDS:g}, "
        f"history={HISTORY_CACHE_TTL_SECONDS:g}, "
        f"create_meta={CREATE_META_CACHE_TTL_SECONDS:g}"
    )
    print(f"Suppress InsecureRequestWarning: {str(args.suppress_insecure_warning)}")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping server...")
    finally:
        bridge.close()
        VERSION_CHECK_EXECUTOR.shutdown(wait=False, cancel_futures=True)
        server.server_close()


if __name__ == "__main__":
    main()
