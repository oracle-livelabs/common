# Source Of Truth

Use these files in this order when they overlap:

1. `gamification-rules.md`
   Path: `/Users/lindafoinding/Documents/Gamify Livelabs/gamification-rules.md`
   Role: policy, placement, scoring defaults, terminology, quiz counts

2. `quiz.md`
   Path: `/Users/lindafoinding/Documents/Gamify Livelabs/quiz.md`
   Role: quiz markdown syntax, `quiz-config`, `quiz`, and `quiz score` behavior

3. `gamification-grade-rubric.md`
   Path: `/Users/lindafoinding/Documents/Gamify Livelabs/gamification-grade-rubric.md`
   Role: QA checklist for grading the finished workshop changes

4. `gamification-prompt.md`
   Path: `/Users/lindafoinding/Documents/Gamify Livelabs/gamification-prompt.md`
   Role: workflow guardrails, repo-safety rules, and reporting expectations

5. Example repositories
   Role: implementation patterns only, not policy

## Example Pattern Files

- Additional lab with manifest update:
  `/Users/lindafoinding/Documents/GitHub/database/hitchhikers-guide-upgrade-to-26ai/workshops/livelabs/manifest.json`
- FastLab append-in-place:
  `/Users/lindafoinding/Documents/GitHub/sprints/fastlab/content/selectai/selectai.md`
- Quiz blocks inside existing lab sections:
  `/Users/lindafoinding/Documents/GitHub/developer/dev-ai-app-dev-gaming/user-story/user-story.md`

## Conflict Rules

- If syntax and policy disagree, keep the placement and behavioral rule from `gamification-rules.md` and the markdown block shape from `quiz.md`.
- Never infer new rules that are not supported by the source-of-truth files.
- Treat example repositories as patterns to imitate, not as authority.
