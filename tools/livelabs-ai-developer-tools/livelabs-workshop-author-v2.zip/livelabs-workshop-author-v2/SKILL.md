---
name: livelabs-workshop-author-v2
description: Create or update Oracle LiveLabs workshops from ideas plus source materials such as blogs, product docs, and web pages. Use when you need a self-contained skill that can start from source-only inputs, scaffold workshop structure, author markdown, capture and place screenshots, incorporate FreeSQL runnable content, emit traceability and QA artifacts, and validate against LiveLabs markdown and Lanham-style rules.
---

# LiveLabs Workshop Author v2

Turn rough workshop ideas and source material into publish-ready LiveLabs workshops with stronger operational support than v1. This version adds explicit authoring modes, prompt templates, traceability guidance, QA delivery guidance, and helper scripts for lab stubs, manifest generation, screenshot capture and staging, FreeSQL block generation, leftover-term scans, source-to-target fidelity checks, and workshop QA.

This skill is intentionally self-contained. If someone downloads only this skill as a zip, the bundled `references/` and `scripts/` folders still provide the guidance and helpers needed to plan, author, illustrate, validate, and package a LiveLabs workshop.

## Quick Start
- Gather source links and artifacts from the user: docs, blogs, product pages, diagrams, commands, screenshots, and sample SQL.
- Choose the best fit mode from `references/mode_selection.md`.
- If you need a prompt shape, start from `references/prompt_templates.md`.
- Scaffold the workshop root:
  - `bash scripts/scaffold_workshop.sh <target-parent-dir> <workshop-slug>`
- Create lab folders and markdown stubs:
  - `bash scripts/create_lab_stub.sh <workshop-root> <lab-slug> <lab-title> [estimated-time]`
- Build or refresh a manifest from the intended lab sequence:
  - `python3 scripts/render_manifest.py <workshop-root> <variant> <workshop-title> <lab-slug=Lab Title> [...]`
- If the workshop needs screenshots, review:
  - `references/screenshot_authoring.md`
  - `node scripts/capture_web_screenshots.mjs <run-name> <url> [url ...]`
  - `bash scripts/stage_screenshots.sh <lab-dir> <source-image> [source-image ...]`
- If the workshop teaches SQL or database tasks, review:
  - `references/freesql_authoring.md`
  - `references/freesql_decision_matrix.md`
  - `references/freesql_site_observations.md`
  - `python3 scripts/render_freesql_block.py <share-url> [--mode link|button|embed]`
- If the workshop has a source scenario or domain to replace, review:
  - `references/industry_conversion.md`
  - `references/source_traceability.md`
  - `bash scripts/scan_leftover_terms.sh <workshop-root> <term> [term ...]`
  - `python3 scripts/compare_workshop_fidelity.py <source-root> <target-root>`
- Run workshop QA:
  - `bash scripts/run_workshop_qa.sh <workshop-root>`

## Modes

Choose one mode up front so the output matches the user's need:

- `draft`: fastest path from source to working markdown skeleton.
- `publish-ready`: full structure, screenshots, FreeSQL decisions, QA pass, and cleanup.
- `how-to-guide`: procedural workshop that teaches authors how to build or publish something.
- `fastlab`: narrow scope, fewer labs, tighter setup, short runtime.
- `industry-conversion`: preserve source teaching flow while converting the scenario and domain language.
- `quiz-ready`: workshop content authored with a clean end-state for quiz generation or gamification.

Use `references/mode_selection.md` for selection rules and delivery expectations.

## Workflow

### 1. Translate Source Content into a Lab Plan
- Convert the input materials into:
  - learner outcome,
  - audience assumptions,
  - environment requirements,
  - ordered labs,
  - per-lab tasks,
  - likely screenshots,
  - FreeSQL opportunities.
- Do not require a pre-existing workshop as input. A blog post or product doc is enough to produce a credible first draft.
- Keep each lab task-focused and action-oriented.
- Map claims, commands, and screenshots back to the source material.
- Use:
  - `references/authoring_workflow.md`
  - `references/source_traceability.md`

### 2. Create the Workshop Skeleton
- Use `scripts/scaffold_workshop.sh` to copy the canonical sample layout.
- Use `scripts/create_lab_stub.sh` to create each lab folder with required sections and an `images/` folder.
- Keep all folder and file names lowercase with dashes.
- Preserve the LiveLabs root layout from `references/workshop_structure.md`.

### 3. Author Markdown Labs
- Follow the section contract for every markdown lab:
  - one H1 as the first non-empty line,
  - `## Introduction`,
  - `### Objectives`,
  - `Estimated Time:` or `Estimated Workshop Time:`,
  - `## Acknowledgements`.
- Use `## Task ...: ...` headers for guided steps.
- Indent nested text, images, lists, and code blocks by 4 spaces inside numbered steps.
- Use meaningful alt text on every image.
- Avoid HTML anchors and invalid embed syntax.
- Use direct, factual language and cut filler early.
- Use `references/markdown_rules.md` as the structural checklist.

### 4. Capture and Place Screenshots
- Use screenshots when they clarify a step, prove a result, or prevent user error.
- Treat screenshots as evidence, not decoration.
- Capture screenshots before the final prose pass so step wording and image placement stay aligned.
- Capture screenshots directly from URLs with:
  - `node scripts/capture_web_screenshots.mjs <run-name> <url> [url ...]`
- Stage or normalize screenshots with:
  - `bash scripts/stage_screenshots.sh <lab-dir> <source-image> [source-image ...]`
- Use `references/screenshot_authoring.md` for naming, placement, and alt-text rules.

### 5. Add FreeSQL Content
- Use FreeSQL when runnable SQL, PL/SQL, Quick SQL, or JavaScript will materially help the learner.
- Decide between plain code, share link, button, or embed with:
  - `references/freesql_authoring.md`
  - `references/freesql_decision_matrix.md`
  - `references/freesql_site_observations.md`
- Generate markdown or HTML blocks from a known FreeSQL share URL with:
  - `python3 scripts/render_freesql_block.py <share-url> [--mode link|button|embed]`
- If the user asks for FreeSQL to appear inside the workshop, inline, embedded, or in-frame, use an embedded editor instead of a link or button.
- When using an embedded editor, prefer the canonical LiveLabs iframe pattern that uses `class="freesql-embed"` and `data-freesql-src="..."`.
- Treat screenshots of successful FreeSQL runs as supporting evidence for the workshop.

### 6. Build Manifests
- Build or refresh `workshops/<variant>/manifest.json` with:
  - `python3 scripts/render_manifest.py <workshop-root> <variant> <workshop-title> <lab-slug=Lab Title> [...]`
- Keep local filenames relative and common labs on approved URLs.
- Keep `index.html` present in each workshop variant folder.
- Use `references/workshop_structure.md` for folder and manifest expectations.

### 7. Tighten Prose
- Review drafts against:
  - `references/ai-generated-content-guide.md`
  - `references/lanham.md`
  - `references/lanham_guidelines.md`
  - `references/lard.md`
- Rewrite weak, vague, or inflated sentences before the validation pass.

### 8. Validate and Repair
- Run:
  - `bash scripts/run_workshop_qa.sh <workshop-root>`
- Resolve failures in this order:
  1. Missing required sections and headers.
  2. Task header format and ordered-list indentation.
  3. Image paths, alt text, image naming, and `<copy>` balance.
 4. FreeSQL links, buttons, or embeds that do not fit the renderer.
 4a. If the user asked for an embed, confirm the final lab contains an iframe-based embed rather than a launch-only affordance.
  5. Time fields and acknowledgements.
  6. Wordy prose and unsupported claims.
- If the workshop was derived from another workshop or domain, run:
  - `bash scripts/scan_leftover_terms.sh <workshop-root> <term> [term ...]`
  - `python3 scripts/compare_workshop_fidelity.py <source-root> <target-root>`

### 9. Package Delivery
- Return:
  - workshop root path,
  - generated and updated files,
  - chosen mode,
  - traceability summary,
  - QA summary,
  - unresolved SME gaps.
- Use `references/qa_delivery_contract.md` as the final output checklist.

## References
- `references/authoring_workflow.md` for converting source materials into a lab blueprint.
- `references/workshop_structure.md` for required folder, manifest, and file layout.
- `references/markdown_rules.md` for validator-aligned markdown constraints.
- `references/screenshot_authoring.md` for screenshot capture, naming, placement, and evidence rules.
- `references/freesql_authoring.md` for adding runnable FreeSQL content.
- `references/freesql_decision_matrix.md` for choosing between code blocks, links, buttons, and embeds.
- `references/freesql_site_observations.md` for current FreeSQL behavior and caveats.
- `references/industry_conversion.md` for source-preserving domain conversion workflow and mapping rules.
- `references/source_traceability.md` for source mapping, evidence tracking, and leftover-term reviews.
- `references/mode_selection.md` for choosing the right authoring mode.
- `references/prompt_templates.md` for playground-ready prompts.
- `references/qa_delivery_contract.md` for final QA and delivery expectations.
- `references/ai-generated-content-guide.md` for concise, defensible AI-assisted writing.
- `references/lanham.md` for the Lanham paramedic method.
- `references/lanham_guidelines.md` for prose scoring and revision cues.
- `references/grading.md` for formal evaluation output when requested.
- `references/lard.md` for word-count reduction examples.

## Scripts
- `scripts/scaffold_workshop.sh` to create a clean workshop scaffold from the canonical sample.
- `scripts/create_lab_stub.sh` to create lab folders, image folders, and markdown stubs with required sections.
- `scripts/render_manifest.py` to generate a manifest from an ordered lab list.
- `scripts/capture_web_screenshots.mjs` to capture reproducible web screenshots into a standard run folder.
- `scripts/stage_screenshots.sh` to copy and normalize screenshot filenames into a lab `images/` folder.
- `scripts/render_freesql_block.py` to render a FreeSQL link, button, or iframe block from a share URL.
- `scripts/scan_leftover_terms.sh` to detect source-domain terms that survived conversion.
- `scripts/compare_workshop_fidelity.py` to compare source and target workshop structure and headings after conversion.
- `scripts/run_workshop_qa.sh` to run local workshop QA and summarize the report path.
