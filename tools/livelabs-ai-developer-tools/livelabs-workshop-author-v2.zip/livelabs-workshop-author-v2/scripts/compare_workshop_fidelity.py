#!/usr/bin/env python3
import re
import sys
from pathlib import Path


TASK_RE = re.compile(r"^##\s+Task\b", re.MULTILINE)
HEADING_RE = re.compile(r"^(#{1,6})\s+(.*)$", re.MULTILINE)


def collect_markdown(root: Path):
    return sorted(p for p in root.rglob("*.md") if "images" not in p.parts)


def summarize_file(path: Path):
    text = path.read_text(encoding="utf-8", errors="ignore")
    headings = [match.group(2).strip() for match in HEADING_RE.finditer(text)]
    task_count = len(TASK_RE.findall(text))
    return {"headings": headings, "task_count": task_count}


def main() -> int:
    if len(sys.argv) != 3 or sys.argv[1] in {"-h", "--help"}:
        print("Usage:\n  compare_workshop_fidelity.py <source-root> <target-root>")
        return 0 if len(sys.argv) == 2 else 1

    source_root = Path(sys.argv[1]).expanduser().resolve()
    target_root = Path(sys.argv[2]).expanduser().resolve()
    if not source_root.is_dir() or not target_root.is_dir():
        print("Both source and target roots must exist.")
        return 1

    source_files = collect_markdown(source_root)
    target_files = collect_markdown(target_root)
    source_rel = {p.relative_to(source_root): p for p in source_files}
    target_rel = {p.relative_to(target_root): p for p in target_files}

    all_rel = sorted(set(source_rel) | set(target_rel))
    mismatches = []

    for rel in all_rel:
        source_path = source_rel.get(rel)
        target_path = target_rel.get(rel)
        if source_path is None:
            mismatches.append((str(rel), "missing in source, present in target"))
            continue
        if target_path is None:
            mismatches.append((str(rel), "present in source, missing in target"))
            continue

        source_summary = summarize_file(source_path)
        target_summary = summarize_file(target_path)
        if source_summary["task_count"] != target_summary["task_count"]:
            mismatches.append(
                (
                    str(rel),
                    f"task-count source={source_summary['task_count']} target={target_summary['task_count']}",
                )
            )
        if source_summary["headings"][:8] != target_summary["headings"][:8]:
            mismatches.append((str(rel), "top headings differ"))

    print(f"Source markdown files: {len(source_files)}")
    print(f"Target markdown files: {len(target_files)}")
    if not mismatches:
        print("No structural fidelity mismatches detected.")
        return 0

    print("Fidelity mismatches:")
    for rel, issue in mismatches:
        print(f"- {rel}: {issue}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
