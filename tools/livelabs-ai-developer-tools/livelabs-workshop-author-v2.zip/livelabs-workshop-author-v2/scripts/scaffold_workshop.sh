#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'USAGE'
Usage:
  scaffold_workshop.sh <target-parent-dir> <workshop-slug> [--sample <sample-workshop-path>] [--force]

Examples:
  scaffold_workshop.sh /tmp my-ai-workshop
  scaffold_workshop.sh /tmp my-ai-workshop --sample /path/to/sample-workshop
USAGE
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

if [[ $# -lt 2 ]]; then
  usage
  exit 1
fi

TARGET_PARENT_DIR="$1"
WORKSHOP_SLUG="$2"
shift 2

SAMPLE_WORKSHOP="${LIVELABS_SAMPLE_WORKSHOP:-/Users/klazarz/Documents/GitHub/livelabs/common/sample-livelabs-templates/sample-workshop}"
FORCE=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --sample)
      SAMPLE_WORKSHOP="${2:-}"
      if [[ -z "${SAMPLE_WORKSHOP}" ]]; then
        echo "--sample requires a path."
        exit 1
      fi
      shift 2
      ;;
    --force)
      FORCE=1
      shift
      ;;
    *)
      echo "Unknown option: $1"
      usage
      exit 1
      ;;
  esac
done

if [[ ! "${WORKSHOP_SLUG}" =~ ^[a-z0-9]+(-[a-z0-9]+)*$ ]]; then
  echo "Invalid workshop slug '${WORKSHOP_SLUG}'. Use lowercase letters, numbers, and dashes only."
  exit 1
fi

if [[ ! -d "${SAMPLE_WORKSHOP}" ]]; then
  echo "Sample workshop path not found: ${SAMPLE_WORKSHOP}"
  exit 1
fi

mkdir -p "${TARGET_PARENT_DIR}"
DEST_DIR="${TARGET_PARENT_DIR%/}/${WORKSHOP_SLUG}"

if [[ -e "${DEST_DIR}" && "${FORCE}" -ne 1 ]]; then
  echo "Destination exists: ${DEST_DIR}"
  echo "Use --force to replace it."
  exit 1
fi

if [[ -e "${DEST_DIR}" && "${FORCE}" -eq 1 ]]; then
  rm -rf "${DEST_DIR}"
fi

cp -R "${SAMPLE_WORKSHOP}" "${DEST_DIR}"

# Remove template and desktop metadata noise from copied sample.
rm -f "${DEST_DIR}/howtouse-deletewhenfinished.md"
find "${DEST_DIR}" -name ".DS_Store" -type f -delete

echo "Workshop scaffold created at: ${DEST_DIR}"
