#!/usr/bin/env node
import fs from "node:fs/promises";
import path from "node:path";

async function ensureDir(dir) {
  await fs.mkdir(dir, { recursive: true });
}

function sanitize(input) {
  return input
    .toLowerCase()
    .replace(/https?:\/\//g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

function usage() {
  console.log(`Usage:
  node scripts/capture_web_screenshots.mjs <run-name> <url> [url ...]

Examples:
  npx --yes -p playwright node scripts/capture_web_screenshots.mjs retail-flow https://example.com
`);
}

const [, , runName, ...urls] = process.argv;
if (!runName || runName === "--help" || runName === "-h") {
  usage();
  process.exit(runName ? 0 : 1);
}
if (urls.length === 0) {
  usage();
  process.exit(1);
}

let chromium;
try {
  ({ chromium } = await import("playwright"));
} catch {
  console.error("Playwright is required. Run with: npx --yes -p playwright node scripts/capture_web_screenshots.mjs ...");
  process.exit(1);
}

const outRoot = path.join(process.cwd(), "output", "screenshots", sanitize(runName));
await ensureDir(outRoot);
const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1440, height: 1024 } });
const manifest = [];

try {
  for (let i = 0; i < urls.length; i += 1) {
    const url = urls[i];
    await page.goto(url, { waitUntil: "networkidle", timeout: 60000 });
    const fileName = `${String(i + 1).padStart(2, "0")}-desktop-${sanitize(url)}.png`;
    const filePath = path.join(outRoot, fileName);
    await page.screenshot({ path: filePath, fullPage: true });
    manifest.push({
      step: i + 1,
      url,
      viewport: "1440x1024",
      capture: "full-page",
      file: fileName,
    });
    console.log(filePath);
  }
} finally {
  await browser.close();
}

const lines = [
  `# Screenshot Manifest: ${runName}`,
  "",
  ...manifest.flatMap((item) => [
    `## ${item.step}. ${item.url}`,
    `- Viewport: ${item.viewport}`,
    `- Capture: ${item.capture}`,
    `- File: ${item.file}`,
    "",
  ]),
];
await fs.writeFile(path.join(outRoot, "manifest.md"), lines.join("\n"), "utf8");
console.log(path.join(outRoot, "manifest.md"));
