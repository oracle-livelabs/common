#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'USAGE'
Usage:
  scan_leftover_terms.sh <workshop-root> <term> [term ...]

Examples:
  scan_leftover_terms.sh /tmp/my-workshop LumenCare healthcare patient
USAGE
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

if [[ $# -lt 2 ]]; then
  usage
  exit 1
fi

WORKSHOP_ROOT="$1"
shift

pattern=""
for term in "$@"; do
  if [[ -n "${pattern}" ]]; then
    pattern="${pattern}|"
  fi
  pattern="${pattern}${term}"
done

rg -n "${pattern}" "${WORKSHOP_ROOT}"
