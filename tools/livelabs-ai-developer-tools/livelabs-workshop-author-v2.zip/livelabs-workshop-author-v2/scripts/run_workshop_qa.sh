#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'USAGE'
Usage:
  run_workshop_qa.sh <workshop-root>

Runs the local workshop validator when available and prints the report path.
USAGE
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

if [[ $# -ne 1 ]]; then
  usage
  exit 1
fi

WORKSHOP_ROOT="$1"
VALIDATOR="${WORKSHOP_VALIDATOR:-/Users/lindafoinding/Documents/codette/workshop-validator/scripts/validate_workshop.py}"

if [[ ! -d "${WORKSHOP_ROOT}" ]]; then
  echo "Workshop root not found: ${WORKSHOP_ROOT}"
  exit 1
fi

if [[ ! -f "${VALIDATOR}" ]]; then
  echo "Validator not found: ${VALIDATOR}"
  echo "Set WORKSHOP_VALIDATOR to the correct validate_workshop.py path."
  exit 1
fi

python3 "${VALIDATOR}" "${WORKSHOP_ROOT}"

REPORT_PATH="${WORKSHOP_ROOT%/}/VALIDATION-RESULT.md"
if [[ -f "${REPORT_PATH}" ]]; then
  echo "Validation report: ${REPORT_PATH}"
else
  echo "Validator completed, but report was not found at: ${REPORT_PATH}"
  exit 1
fi
