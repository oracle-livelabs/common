#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'USAGE'
Usage:
  stage_screenshots.sh <lab-dir> <source-image> [source-image ...]

Examples:
  stage_screenshots.sh /tmp/my-workshop/setup ~/Desktop/Shot\ 1.png ~/Desktop/Shot\ 2.png
USAGE
}

slugify() {
  local input="$1"
  input="$(printf '%s' "${input}" | tr '[:upper:]' '[:lower:]')"
  input="${input// /-}"
  input="$(printf '%s' "${input}" | sed -E 's/[^a-z0-9._-]+/-/g; s/-+/-/g; s/^-//; s/-$//')"
  printf '%s' "${input}"
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

if [[ $# -lt 2 ]]; then
  usage
  exit 1
fi

LAB_DIR="$1"
shift

IMAGES_DIR="${LAB_DIR%/}/images"
mkdir -p "${IMAGES_DIR}"

for source in "$@"; do
  if [[ ! -f "${source}" ]]; then
    echo "Missing source image: ${source}"
    exit 1
  fi

  base="$(basename "${source}")"
  stem="${base%.*}"
  ext="${base##*.}"
  target_name="$(slugify "${stem}").$(printf '%s' "${ext}" | tr '[:upper:]' '[:lower:]')"
  cp "${source}" "${IMAGES_DIR}/${target_name}"
  echo "${source} -> ${IMAGES_DIR}/${target_name}"
done
