# FreeSQL Decision Matrix

Use this file to choose the right FreeSQL format for a lab.

## Choose the Simplest Format That Works

### Plain SQL or PL/SQL code block

Use when:
- the learner mainly needs to read or copy the code,
- the renderer should stay simple,
- you do not need a runnable call-to-action.

### Share link

Use when:
- the learner should open runnable SQL in FreeSQL,
- markdown output should stay clean,
- raw HTML is unnecessary.

### Run in FreeSQL button

Use when:
- the renderer allows raw HTML,
- a strong call-to-action helps,
- the workshop benefits from a visible launch affordance.

### Embedded editor

Use when:
- raw HTML is allowed,
- inline execution materially improves the lab,
- extra complexity is justified.

## Decision Rules

- For standard lab markdown, prefer a share link unless the user explicitly wants a button or embed.
- For authoring demos and polished how-to guides, a button can help if rendering supports it.
- Use an embed only when the user asks for it or when the workshop environment clearly supports raw HTML.
- Treat these phrases as a direct embed request: `embedded`, `in the workshop`, `inline`, `in-frame`, `inside the lab`, `do not make me leave the page`.
- If the user asks for an embed, do not return a launch link, launch button, or separate FreeSQL step as the primary answer.
- For LiveLabs markdown, a button request should render as `<freesql-button src="...">`, not a generic HTML anchor wrapper.
- For LiveLabs markdown, an embed request should render as the canonical `iframe.freesql-embed` block with `data-freesql-src`.

## Evidence Rule

If the lab uses FreeSQL and you claim the example works:

- run it when feasible,
- capture the result,
- keep that screenshot as supporting evidence.
