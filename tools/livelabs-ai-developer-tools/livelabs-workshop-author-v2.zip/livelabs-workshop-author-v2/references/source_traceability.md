# Source Traceability

Use this reference when the workshop draws from blogs, docs, demos, screenshots, or an existing workshop.

## Goal

Keep claims, commands, screenshots, and scenario details tied to the source material so the workshop remains defensible.

## What To Track

Track these items while authoring:

- major claims,
- commands and code blocks,
- environment assumptions,
- screenshots and their source state,
- scenario or domain mappings,
- open questions that still need SME input.

## Minimal Traceability Table

Use a simple table while drafting:

| Workshop Area | Source | Evidence Type | Notes |
| --- | --- | --- | --- |
| Lab 1 intro | Blog post section 2 | claim | Reworded for workshop audience |
| Task 3 SQL | product doc | command | Adjusted schema names only |
| Screenshot 2 | source UI | image | Captures launch button state |

## Conversion Checks

When converting an existing workshop:

- preserve the original teaching flow,
- map scenario nouns before rewriting prose,
- scan for leftover source terms after the rewrite,
- preserve screenshots unless they are wrong for the new domain,
- do not invent new technical behaviors not present in the source.
- verify that lab titles, manifest descriptions, quiz questions, captions, and alt text all match the target scenario,
- verify that company-specific outcomes sound native to the new industry rather than generic.

## Leftover-Term Review

Run a leftover-term scan when the source contains strong domain language. Search for:

- company names,
- industry nouns,
- schema names,
- statuses,
- IDs,
- UI labels that should have changed.

Use `scripts/scan_leftover_terms.sh` for a quick pass.
