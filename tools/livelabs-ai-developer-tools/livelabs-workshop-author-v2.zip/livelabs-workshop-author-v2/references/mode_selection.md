# Mode Selection

Choose one mode before drafting. The mode controls how much structure, polish, and QA the skill should apply.

## Modes

### draft

Use when speed matters more than polish.

Deliver:
- workshop skeleton,
- lab plan,
- first-pass markdown,
- basic manifest coverage.

Do not stop here if the user asked for publish-ready output.

### publish-ready

Use when the workshop should be ready for serious review or direct testing.

Deliver:
- complete markdown,
- manifests,
- screenshot placement,
- FreeSQL decisions,
- validator pass,
- compact QA summary.

### how-to-guide

Use when the workshop teaches a process, authoring flow, or product setup sequence.

Favor:
- outcome-based lab titles,
- procedural steps,
- screenshots at checkpoints,
- short explanations tied to the task.

### fastlab

Use when the workshop should stay narrow and quick.

Favor:
- fewer labs,
- tighter setup,
- minimal prerequisites,
- only the highest-value screenshots and examples.

### industry-conversion

Use when the source already exists and the teaching flow should stay intact.

Favor:
- source fidelity,
- terminology mapping,
- leftover-vocabulary scans,
- minimal rewrites outside the scenario layer.

### quiz-ready

Use when the workshop will later feed quiz or gamification work.

Favor:
- clean objectives,
- stable task boundaries,
- explicit outcomes,
- consistent terminology.

## Selection Rules

- If the user says "publish-ready," choose `publish-ready`.
- If the user provides only raw ideas or a blog post, start in `draft` unless they ask for more.
- If the workshop is instructional about building something, choose `how-to-guide`.
- If the user says "convert this workshop to retail/finance/etc.," choose `industry-conversion`.
- If the user gives a company name with the industry, carry that company through titles, scenarios, examples, and assessments.
- If the user asks for a short workshop or fastlab, choose `fastlab`.
- If the user plans to add quizzes, choose `quiz-ready`.
