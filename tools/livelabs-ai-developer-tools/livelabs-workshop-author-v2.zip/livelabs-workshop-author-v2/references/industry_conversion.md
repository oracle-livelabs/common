# Industry Conversion

Use this workflow when the workshop already exists and the goal is to convert it to a target industry without flattening the source.

## Goal

Preserve:
- lab order,
- task coverage,
- technical teaching flow,
- screenshots where still valid,
- generic instructional prose.

Change:
- company and scenario language,
- schema names when needed,
- sample data and statuses,
- screenshots that are wrong for the new domain,
- any source nouns that break the target scenario.

## Workflow

1. Treat the source workshop as canonical.
2. Build a source-to-target mapping table before rewriting.
3. Rewrite only the domain-sensitive parts first:
   - intro,
   - scenario sections,
   - sample data,
   - screenshots and captions,
   - manifests if the title or descriptions should change.
4. Keep generic technical explanation close to the source.
5. Run leftover-term scans on company names, industry nouns, schema names, and statuses.
6. Run a source-to-target fidelity comparison after repairs.
7. Rewrite outcomes, scenario framing, and quiz language so they sound native to the target company and industry, not generic.
8. Review every screenshot, caption, alt text, manifest title, and lab description for source-domain leakage.

## Required Mapping Inputs

Capture these before writing:

- target industry,
- target company name,
- target customer or user persona,
- target business objects such as order, claim, account, store, loan, or policy,
- target statuses and workflow states,
- any target KPIs or business outcomes that should appear in lab titles and summaries.

If any of these are missing, infer only the minimum needed and record the assumptions.

## Minimal Mapping Table

| Source Term | Target Term | Notes |
| --- | --- | --- |
| patient | customer | only in scenario-specific labs |
| appointment | order | preserve technical meaning where needed |
| clinic | store | only when scenario-specific |

## Red Flags

- Overwriting generic technical content that did not need conversion.
- Leaving source screenshots that contradict the new scenario.
- Changing section order or task count without a real reason.
- Replacing precise source logic with vague industry wording.
- Rewriting the workshop into bland marketing language that no longer teaches the same task.
- Leaving the original company's nouns in quiz answers, captions, or sample data.
- Changing technical examples when only the scenario language needed to change.

## Required Checks

- leftover-term scan,
- manifest review,
- screenshot review,
- fidelity comparison of headings and task counts.
- file and folder name review when names themselves expose the old scenario,
- quiz and assessment review if the source includes knowledge checks,
- outcome-title review so lab titles describe target-user results, not generic features.
