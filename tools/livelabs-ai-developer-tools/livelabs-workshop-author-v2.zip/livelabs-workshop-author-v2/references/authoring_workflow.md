# Source-to-Workshop Authoring Workflow

Use this workflow when the user provides an idea plus source content. A prior workshop is optional, not required.

## 1. Collect Inputs

Capture:

- workshop audience,
- target environment (`tenancy`, `sandbox`, `desktop`),
- expected duration,
- core outcomes,
- source links and documents.
- whether the source material is a blog post, product doc, slide deck, demo script, or an existing workshop.
- whether the workshop should include runnable SQL through FreeSQL.

If key details are missing, make conservative assumptions and document them.

## 2. Build a Lab Blueprint

Create a minimal blueprint before writing markdown:

- `Introduction` lab: storyline and expected outcomes.
- Lab sequence (`Lab 1`, `Lab 2`, ...): one clear goal per lab.
- Task sequence per lab: one action per numbered step.

Prefer 3-6 labs for first draft unless user requests otherwise.
If the workshop is a creator guide, place the first hands-on how-to material in `Lab 1`.
If the only source is a blog post, derive the lab plan from the blog's problem, workflow, commands, and outcomes rather than mirroring its section headings mechanically.

## 3. Convert Source Material into Steps

For each source:

- extract concrete actions and commands,
- remove marketing language,
- keep syntax and parameter names exact,
- cite source links in `Learn More` when relevant.
- convert narrative claims into learner actions, checkpoints, and expected results.

Avoid unsupported claims that are not in provided sources.

## 4. Draft Markdown with LiveLabs Conventions

For each lab markdown file:

- keep one H1,
- add required `Introduction`, `Objectives`, `Estimated Time`, `Acknowledgements`,
- create `## Task ...: ...` blocks for guided execution,
- indent all content inside numbered steps by 4 spaces.
- keep examples, commands, and parameter names exact.
- use meaningful image alt text and lowercase image filenames.

## 5. Add FreeSQL Assets When Appropriate

If the workshop teaches SQL, PL/SQL, Quick SQL, or related database actions:

- decide whether the learner only needs a code block, or whether a runnable FreeSQL experience adds value,
- prefer a share link in markdown by default,
- use a `Run in FreeSQL` button only when HTML is acceptable,
- use the embedded editor only when inline execution clearly improves the lab and the renderer allows raw HTML,
- capture screenshots after successful execution and store them as evidence or supporting assets.

Use these local references:

- `freesql_authoring.md`
- `freesql_site_observations.md`

## 6. Tighten Prose Before Validation

Before you validate structure, tighten the prose:

- remove filler, hype, and vague adjectives,
- prefer active voice and concrete verbs,
- use problem -> solution -> outcome flow when that makes the lab easier to follow,
- apply the Lanham paramedic method to long or slow sentences,
- cut unsupported claims or mark them as TODO items for SME review.

Use these local references:

- `ai-generated-content-guide.md`
- `lanham.md`
- `lanham_guidelines.md`
- `grading.md` when the user requests formal grading
- `lard.md` when the user requests reduction examples or sentence tightening

## 7. Assemble Manifests

Update `workshops/<variant>/manifest.json`:

- set a precise `workshoptitle`,
- add prerequisite shared labs when needed,
- order tutorial entries exactly as learner flow,
- point `filename` values to valid relative files or approved URLs.

## 8. Validate and Iterate

Run validator:

`/Users/klazarz/Documents/GitHub/livelabs/common/md-validator/.github/scripts/validate-livelabs-markdown.sh <workshop-root>`

Fix all failures, rerun, and stop only at zero errors.

Repair in this order:

1. Structure and missing files.
2. Required markdown sections and task formatting.
3. Images, embeds, custom tags, and FreeSQL integration choices.
4. Manifest issues.
5. Lanham and clarity issues that still weaken the learner flow.
