# QA Delivery Contract

Use this checklist before declaring the workshop ready.

## Required Delivery Items

Return:

- workshop root path,
- mode used,
- created and updated files,
- screenshot summary,
- FreeSQL summary,
- validator status,
- unresolved SME or source gaps.

## QA Checklist

- Required markdown sections are present.
- Manifests point to real files.
- Image paths resolve.
- Image alt text is meaningful.
- FreeSQL links or embeds match the renderer.
- Prose is direct and defensible.
- Leftover source-domain terms were checked when relevant.

## Screenshot Summary

Summarize:

- which labs got screenshots,
- whether images came from source assets or new captures,
- any screenshots still missing.

## FreeSQL Summary

Summarize:

- which labs include FreeSQL content,
- whether the lab uses plain code, share links, buttons, or embeds,
- any examples that still need live verification.

## Unresolved Gaps

Be explicit about:

- missing SME confirmation,
- missing assets,
- screenshots still needed,
- commands not runtime-tested,
- validator issues outside the edited surface.
