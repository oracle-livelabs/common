# Screenshot Authoring

Use screenshots when they make a LiveLabs step clearer, faster to follow, or easier to verify.

## When to Capture

Capture screenshots for:
- launch points and setup checkpoints,
- console states the learner must match,
- FreeSQL results,
- product UI states that are easy to miss,
- before and after states when the change matters.

Do not add screenshots as decoration. Every screenshot should support a specific step.

## Capture Priority

Prefer this order:

1. Browser automation or browser devtools when the target is a web page.
2. FreeSQL browser workflow when the target is a FreeSQL run.
3. Existing source screenshots when they are accurate and reusable.
4. OS-level screenshots only when browser capture is not practical.

## Workflow

1. Decide which states matter before capturing.
2. Capture only the states the learner needs.
3. Save images into the target lab's `images/` folder.
4. Use lowercase filenames with dashes.
5. Add the image under the step it supports.
6. Write alt text that describes what the learner should notice.

## Naming

Use descriptive filenames such as:

- `launch-workshop-button.png`
- `database-actions-open-menu.png`
- `freesql-query-results.png`
- `vector-search-output.png`

Avoid generic names such as `image1.png` or `screenshot-final.png` unless you are preserving source assets you cannot rename safely.

## Placement Rules

- Put the screenshot directly under the numbered step it supports.
- Indent the image to align with the step.
- Keep one screenshot per distinct state when possible.
- If a step needs two screenshots, ensure each image shows a different state or a different target.

Example:

```md
1. Open the SQL worksheet.

    ![The SQL worksheet is open and ready for input.](./images/sql-worksheet-open.png =60%x*)
```

## Alt Text

Good alt text describes the visible state and the intended learner cue.

Good:
- `The Run in FreeSQL button appears below the code sample.`
- `The query result grid shows three returned rows.`
- `The Database Actions menu highlights SQL.`

Weak:
- `Screenshot`
- `Image 1`
- `UI`

## FreeSQL Evidence Rule

When a lab uses FreeSQL:

- capture a screenshot after each successful run that materially changes the visible result,
- capture the error state too if the failure itself is instructional,
- do not clear the worksheet before capturing the result,
- use the screenshot as proof of the example, not filler.

## Render Safety

- Prefer PNG.
- Keep paths relative to the markdown file.
- Ensure the referenced file exists before delivery.
- Recheck image indentation after validator fixes so screenshots still align with the correct task step.
