# FreeSQL Authoring For LiveLabs

Use this reference when a workshop should include runnable SQL, PL/SQL, Quick SQL, or JavaScript examples through FreeSQL.

## When To Use FreeSQL

Use FreeSQL when learners benefit from executing code rather than only reading it. Typical cases:

- SQL query walkthroughs
- PL/SQL exercises
- Quick SQL generation examples
- JavaScript database examples in supported contexts

Do not force FreeSQL into every lab. Plain code blocks are often enough when the learner does not need a runnable environment.

## Default Output Choice

Choose the simplest option that fits the lab:

1. Plain code block: best when the lab only needs readable code.
2. Share link: best default for markdown deliverables.
3. `Run in FreeSQL` button: use only when HTML is allowed and a visible call-to-action helps.
4. Embedded editor: use only when raw HTML is allowed and inline execution materially improves the learning flow.

When the user asks for markdown and does not ask for embeddable HTML, prefer the share link.
When the user explicitly asks for FreeSQL inside the workshop, embedded, in-frame, or inline, skip the link and button options and use the embedded editor.

## Authoring Workflow

1. Open FreeSQL in a real browser.
2. Clear blockers such as cookie consent and tours before interacting with the editor.
3. Enter the SQL or PL/SQL code.
4. Execute the statement or script.
5. Confirm the result pane changed or an error is visible.
6. Take a screenshot immediately after execution.
7. Generate the required share artifact only after the code is confirmed.

If execution fails, capture the error state as a screenshot as well.

## Sharing Modes

FreeSQL supports:

- `Share Link`
- `Run in FreeSQL Button`
- `Embedded Editor`

Use them this way:

- `Share Link`: best for markdown links and most LiveLabs lab content.
- `Run in FreeSQL Button`: best when the target renderer supports HTML and you want a stronger visual call-to-action.
- `Embedded Editor`: best when the target renderer supports raw HTML and the lab benefits from an inline runnable editor.

For LiveLabs, the canonical embedded form is:

```html
<iframe
            class="freesql-embed"
            data-freesql-src="<embedded FreeSQL URL>"
            height="460px"
            width="100%"
            scrolling="no"
            frameborder="0"
            allowfullscreen="true"
            name="FreeSQL Embedded Playground"
            title="FreeSQL"
            style="width: 100%; border: 1px solid #e0e0e0; border-radius: 12px; overflow: hidden;"
        >FreeSQL Embedded Playground</iframe>
```

## LiveLabs Guidance

- Prefer normal markdown links unless there is a clear reason to use HTML.
- Do not assume every LiveLabs rendering path will allow iframe embeds.
- Treat screenshots as proof assets for the workshop, not decoration.
- Keep code examples aligned with the task sequence in the lab.
- If a FreeSQL artifact is too large or the share payload fails, fall back to a code block plus screenshot and learner instructions.
- If the user explicitly asks for an embed, do not silently downgrade to a link or button. Either provide the embed or state why it is blocked.
- Prefer the native `<freesql-button src="...">` form over arbitrary HTML button wrappers when a button is requested.

## Validation Checks

- The executed code is visible in the editor or output area.
- The result pane changed or showed a meaningful error.
- A screenshot exists for the run.
- The generated share link, button code, or iframe snippet matches the requested output type.

Use `freesql_site_observations.md` for current entry points, known UI blockers, and share behavior.
