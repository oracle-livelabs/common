---
name: livelabs-workshop-author
description: Create or update Oracle LiveLabs workshops from ideas plus source materials such as blogs, product docs, and web pages. Use when you need a workshop folder with correct LiveLabs structure, manifests, and markdown that passes the LiveLabs markdown validator rules.
---

# LiveLabs Workshop Author

Turn rough workshop ideas and source material into publish-ready LiveLabs workshops that follow Oracle structure and markdown standards.

## Quick Start
- Gather source links and artifacts from the user: docs, blogs, product pages, architecture diagrams, and sample commands.
- Scaffold a new workshop from the canonical sample:
  - `bash scripts/scaffold_workshop.sh <target-parent-dir> <workshop-slug>`
- Draft the workshop flow and lab list before writing markdown.
- Author `introduction/introduction.md`, lab markdown files, and `workshops/*/manifest.json`.
- Run the official markdown validator:
  - `/Users/klazarz/Documents/GitHub/livelabs/common/md-validator/.github/scripts/validate-livelabs-markdown.sh <workshop-root>`
- Fix all failures and rerun until clean.

## Workflow

### 1. Translate Source Content into a Lab Plan
- Convert the input materials into a workshop narrative:
  - learner outcome,
  - environment assumptions,
  - ordered labs,
  - per-lab tasks.
- Keep each lab task-focused and action-oriented.
- Map every major claim or command back to a provided source.
- Use `references/authoring_workflow.md` when the user provides many sources.

### 2. Create the Workshop Skeleton
- Use `scripts/scaffold_workshop.sh` to copy the canonical sample layout.
- Keep all folder and file names lowercase with dashes.
- Preserve the required LiveLabs root layout described in `references/workshop_structure.md`.

### 3. Author Markdown Labs
- Follow the section contract for every markdown lab:
  - first non-empty line is exactly one H1,
  - `## Introduction`,
  - `### Objectives`,
  - `Estimated Time:` (or `Estimated Workshop Time:` in `introduction.md`),
  - `## Acknowledgements`.
- Use `## Task ...: ...` headers for guided steps.
- For ordered steps, indent nested text, images, lists, and code blocks by 4 spaces.
- Use meaningful alt text on every image.
- Avoid HTML anchors and invalid embed syntax.
- Use `references/markdown_rules.md` as the definitive authoring checklist.

### 4. Build Workshop Manifests
- Update each required `workshops/<variant>/manifest.json`:
  - set `workshoptitle`,
  - include `help`,
  - include `variables` when needed,
  - list `tutorials` in the intended learning sequence.
- Use relative file references for local labs and approved URLs for shared common labs.
- Keep `index.html` present in each workshop variant folder.
- Structure patterns live in `references/workshop_structure.md`.

### 5. Validate and Repair
- Run the official validator script against the workshop root.
- Resolve failures in this order:
  1. Missing required sections and headers.
  2. Task header format and ordered-list indentation.
  3. Image alt text, image naming, embeds, and `<copy>` balance.
  4. Time fields and acknowledgements.
- Repeat until the validator passes with zero errors.

### 6. Final Delivery
- Return the workshop root path and list of generated/updated files.
- Summarize remaining TODO placeholders that still need SME input.
- If required assets were copied from outside the repo, remove temporary copies after authoring is complete.

## References
- `references/authoring_workflow.md` for converting source materials into a lab blueprint.
- `references/workshop_structure.md` for required folder, manifest, and file layout.
- `references/markdown_rules.md` for validator-aligned markdown constraints.

## Scripts
- `scripts/scaffold_workshop.sh` to create a clean workshop scaffold from the canonical sample.
