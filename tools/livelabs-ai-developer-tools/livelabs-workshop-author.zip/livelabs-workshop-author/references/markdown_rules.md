# LiveLabs Markdown Rules (Validator-Aligned)

These rules mirror the checks from `validate-livelabs-markdown.sh`.

## Required Sections and Headers

- First non-empty line must be H1 (`# Title`).
- Allow only one H1 per file (excluding fenced code blocks).
- Include `## Acknowledgements` in every markdown file.
- If a file has any `## Task` section, include `## Introduction`.
- Include `### Objectives` or `## Objectives`.

Time labels:

- `introduction.md` must include `Estimated Workshop Time:`.
- Other lab files must include an `Estimated ... Time:` label.

## Task and Step Format

- Task headings must follow:
  - `## Task Number and/or string: Description`
- Numbered list items must use a single space after the period:
  - valid: `1. Step`
  - invalid: `1.\tStep`
  - invalid: `1.  Step`

## Ordered-List Indentation Rules

Inside numbered steps, indent nested content by 4 spaces:

- paragraphs,
- images,
- sub-lists,
- fenced code blocks.

Exceptions in validator logic:

- Raw HTML element lines may remain unindented.
- A trailing unindented transition line is allowed only when no later numbered step exists.
- Top-level headings terminate ordered-list indentation scope.

## Images and Links

- Every image reference needs alt text:
  - valid: `![Alt text](images/example.png)`
  - invalid: `![](images/example.png)`
- Image filenames in markdown references must be lowercase.
- HTML anchors are forbidden:
  - invalid: `<a href="...">`
  - valid: `[Link text](https://...)`

## Embedded Media and Custom Tags

- YouTube embeds must follow markdown-link syntax:
  - `[Optional text](youtube:VIDEO_ID[:size])`
- Keep `<copy>` and `</copy>` tags balanced.
