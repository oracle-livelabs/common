# Source-to-Workshop Authoring Workflow

Use this workflow when the user provides an idea plus source content.

## 1. Collect Inputs

Capture:

- workshop audience,
- target environment (`tenancy`, `sandbox`, `desktop`),
- expected duration,
- core outcomes,
- source links and documents.

If key details are missing, make conservative assumptions and document them.

## 2. Build a Lab Blueprint

Create a minimal blueprint before writing markdown:

- `Introduction` lab: storyline and expected outcomes.
- Lab sequence (`Lab 1`, `Lab 2`, ...): one clear goal per lab.
- Task sequence per lab: one action per numbered step.

Prefer 3-6 labs for first draft unless user requests otherwise.

## 3. Convert Source Material into Steps

For each source:

- extract concrete actions and commands,
- remove marketing language,
- keep syntax and parameter names exact,
- cite source links in `Learn More` when relevant.

Avoid unsupported claims that are not in provided sources.

## 4. Draft Markdown with LiveLabs Conventions

For each lab markdown file:

- keep one H1,
- add required `Introduction`, `Objectives`, `Estimated Time`, `Acknowledgements`,
- create `## Task ...: ...` blocks for guided execution,
- indent all content inside numbered steps by 4 spaces.

## 5. Assemble Manifests

Update `workshops/<variant>/manifest.json`:

- set a precise `workshoptitle`,
- add prerequisite shared labs when needed,
- order tutorial entries exactly as learner flow,
- point `filename` values to valid relative files or approved URLs.

## 6. Validate and Iterate

Run validator:

`/Users/klazarz/Documents/GitHub/livelabs/common/md-validator/.github/scripts/validate-livelabs-markdown.sh <workshop-root>`

Fix all failures, rerun, and stop only at zero errors.
