# LiveLabs Workshop Structure

Use this as the canonical skeleton for new workshops.

## Required Root Layout

```
<workshop-root>/
  introduction/
    introduction.md
  <lab-a>/
    <lab-a>.md
    images/
    files/                # optional
  <lab-b>/
    <lab-b>.md
    images/
    files/                # optional
  variables/              # optional
    variables.json
  workshops/
    tenancy/
      index.html
      manifest.json
    sandbox/
      index.html
      manifest.json
    desktop/
      index.html
      manifest.json
```

## Folder and File Naming

- Use lowercase names and dashes only.
- Keep each lab markdown filename equal to its folder name:
  - `setup/setup.md`
  - `data-load/data-load.md`
- Keep image filenames lowercase.

## Manifest Requirements

Each `workshops/<variant>/manifest.json` should include:

- `workshoptitle`
- `help` (team alias)
- `tutorials` array with ordered workshop flow
- `variables` array when variable files are used
- `include` object when external files are injected into rendering

Each tutorial item should include:

- `title`
- `filename`
- `description` when useful

Use:

- relative paths for local labs, for example `../../setup/setup.md`
- approved absolute URLs for shared common labs

## Typical Tutorial Sequence

Depending on variant, use this order pattern:

1. `Get Started` prerequisite lab (optional but common in sandbox/tenancy)
2. `Introduction`
3. `Lab 1 ...`
4. `Lab 2 ...`
5. additional labs
6. `Need Help?`

## Canonical Source Paths

- Sample workshop:
  - `/Users/klazarz/Documents/GitHub/livelabs/common/sample-livelabs-templates/sample-workshop`
- LiveLabs markdown validator:
  - `/Users/klazarz/Documents/GitHub/livelabs/common/md-validator/.github/scripts/validate-livelabs-markdown.sh`
